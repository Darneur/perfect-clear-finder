package oki.avl;
    /**
     * Wrapper class for use with generic data structures.
     * Mimics Integer.
     * In Java 1.2, you can use Integer if Comparable is needed.
     * @author Mark Allen Weiss
     */
    @SuppressWarnings({"rawtypes"})
	public final class MyInteger implements Comparable
    {
    	private int value;
    	
        public MyInteger( )
        {
            this( 0 );
        }

        public MyInteger( int x )
        {
            value = x;
        }

        public int intValue( )
        {
            return value;
        }

        public String toString( )
        {
            return Integer.toString( value );
        }

        public boolean equals( Object rhs )
        {
            return rhs != null && value == ((MyInteger)rhs).value;
        }

		public int compareTo(Object rhs) 
		{
            return value < ((MyInteger)rhs).value ? -1 :
                value == ((MyInteger)rhs).value ? 0 : 1;
		}
    }