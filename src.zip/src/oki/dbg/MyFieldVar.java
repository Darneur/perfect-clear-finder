package oki.dbg;

public class MyFieldVar extends MyField
{
	short row0, row1, row2, row3, row4, row5, row6, row7;
	short height;
	
	public MyFieldVar( short height )
	{
		super(height);
		this.height = height;
	}
	
	public MyFieldVar( boolean[][] matrix )
	{
		super(matrix);
		this.height = (short) matrix.length;
	}
	
	public MyFieldVar( MyFieldVar other )
	{
		super(other);
		this.height = other.height;
		row0 = other.row0;
		row1 = other.row1;
		row2 = other.row2;
		row3 = other.row3;
		row4 = other.row4;
		row5 = other.row5;
		row6 = other.row6;
		row7 = other.row7;
	}
	
	protected MyField makeCopy()
	{
		return new MyFieldVar( this );
	}
	
	
	protected int getHeight()
	{
		return this.height;
	}
	
	protected int compareMatrix( MyField obj )
	{
		MyFieldVar other = (MyFieldVar) obj;
		if ( row0 < other.row0 )
			return -1;
		else if (row0 > other.row0 )
			return +1;
		if ( row1 < other.row1 )
			return -1;
		else if (row1 > other.row1 )
			return +1;
		if ( row2 < other.row2 )
			return -1;
		else if (row2 > other.row2 )
			return +1;
		if ( row3 < other.row3 )
			return -1;
		else if (row3 > other.row3 )
			return +1;
		if ( row4 < other.row4 )
			return -1;
		else if (row4 > other.row4 )
			return +1;
		if ( row5 < other.row5 )
			return -1;
		else if (row5 > other.row5 )
			return +1;
		if ( row6 < other.row6 )
			return -1;
		else if (row6 > other.row6 )
			return +1;		
		if ( row7 < other.row7 )
			return -1;
		else if (row7 > other.row7 )
			return +1;
		return 0;
	}
	
	private short getRow( int row )
	{
		if ( row == 0 )
			return row0;
		else if ( row == 1 )
			return row1;
		else if ( row == 2 )
			return row2;
		else if ( row == 3 )
			return row3;
		else if ( row == 4 )
			return row4;
		else if ( row == 5 )
			return row5;
		else if ( row == 6 )
			return row6;
		else // if ( row == 7 )
			return row7;
	}
	
	private void setRow( int row, short value )
	{
		if ( row == 0 )
			row0 = value;
		else if ( row == 1 )
			row1 = value;
		else if ( row == 2 )
			row2 = value;
		else if ( row == 3 )
			row3 = value;
		else if ( row == 4 )
			row4 = value;
		else if ( row == 5 )
			row5 = value;
		else if ( row == 6 )
			row6 = value;
		else // if ( row == 7 )
			row7 = value;
	}
	
	protected boolean filled( int row, int col )
	{
		return ( (getRow(row)>>col)&1) != 0;
	}
	
	protected void fillCell( int row, int col )
	{
		short value = getRow( row );
		value ^= 1 << col;
		setRow( row, value );
	}
	
	protected void makeEmpty( int row )
	{
		setRow( row, emptyrow );
	}

	protected boolean isFull( int row )
	{
		return ( getRow(row) == emptyrow );
	}
	
	protected void replaceWith( int oldRow, int newRow  )
	{
		short value = getRow( newRow );
		setRow( oldRow, value );
	}
	
	
	protected void reduceHeight( int newHeight )
	{
		this.height = (short) newHeight;
	}
}
