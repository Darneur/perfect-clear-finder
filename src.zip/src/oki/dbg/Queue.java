package oki.dbg;


public class Queue<E>
{
	private Node<E> head;
	private Node<E> tail;
	private Node<E> curr;
	
	public int currID;
	public int lastID;
	
	public Queue() 
	{
        head = new Node<E>();
        tail = head;
        curr = head;
        currID = 0;
        lastID = 0;
    }
	
	public void add(E data)
	{
		Node<E> help = new Node<E>(data);
		tail.next = help;
		tail = help;
		lastID += 1;
	}
	
	public void reset()
	{
		curr = head;
		currID = 0;
	}
	
	public boolean hasNext()
	{
		if ( curr.next != null )
			return true;
		else
			return false;
	}
	
	public E next()
	{
		curr = curr.next;
		currID += 1;
		return curr.data;
	}
}

class Node<E>
{
	protected Node<E> next;
	protected E data;
	
	protected Node(){}
	protected Node(E data){this.data = data;}
}