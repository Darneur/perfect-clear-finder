package oki.dbg;
import oki.avl.AvlTree;
import oki.pc.FieldArr;
import oki.pc.PerfectClearArr;

public class MyPerfectClearArr
{
	public static final int check_Surface = 0,
							check_Softdrop = 1,
							check_Deepdrop = 2;
	
	static int check = check_Softdrop;
	static boolean debug = false;
	static int nodeLimit = 100000000;
	static boolean checkForSplits = true;
	static boolean multipleSolutions = true;
	
	short[] pieces; // given piece sequence (first piece is put on hold)
	Queue<MyField>[] queue; // queue[depth], list containing the data of all created fields
	AvlTree[] tree; // tree[depth], sorts all created fields
	int[] mergings;
	
	@SuppressWarnings("unchecked")
	public MyPerfectClearArr( boolean[][] matrix, short[] pieces )
	{
		// matrix[row][col] whereas row = 0 means bottom, and col = 0 means left side
		this.pieces = pieces;
		MyField startField = new MyFieldArr( matrix );
		startField.setPiece ( pieces[0] );
		startField.setAncestor( null );
		startField.setPaths( 1 );
		
		queue = new Queue[pieces.length];
		tree = new AvlTree[pieces.length];
		mergings = new int[pieces.length-1];
			
		queue[0] = new Queue<MyField>();
		tree[0] = new AvlTree();
		queue[0].add(startField);
		tree[0].insert(startField);
		
		MyField.calculateAdjustedKicks();
	}
	
	public static boolean acceptMove( MyField field, short[] location )
	{
		if ( check == check_Softdrop && !field.locationIsReachable(location) )
			return false;
		else if ( check == check_Surface && !field.locationOnSurface(location) )
			return false;
		else if ( checkForSplits && field.hasOddSplit() )
			return false;
		return true;
	}
	
	public void process(int depth)
	{
		queue[depth+1] = new Queue<MyField>();
		tree[depth+1] = new AvlTree();
		Queue<MyField> thisQueue = queue[depth];
		Queue<MyField> nextQueue = queue[depth+1];
		AvlTree nextTree = tree[depth+1];
		short activePiece = pieces[depth+1];
		int duplicates = 0;
		
		while( thisQueue.hasNext() && nextQueue.lastID < nodeLimit )
		{
			if ( debug )
				System.out.println( "( " + thisQueue.currID + " / " + thisQueue.lastID + " )" + " , " + duplicates );
			MyField thisField = thisQueue.next();
			for ( int counter = 0; counter < 1; counter++ ) // <-- ( thisField.piece == activePiece ? 2 : 1 )
			{
				short[] location = thisField.resetLocation(activePiece);
				while ( thisField.getNextLocation(location) )
				{
					if ( !acceptMove( thisField, location ) )
						continue;
//					if ( check == check_Softdrop && !thisField.locationIsReachable(location) )
//						continue;
//					else if ( check == check_Surface && !thisField.locationOnSurface(location) )
//						continue;
//					else if ( checkForSplits && thisField.hasOddSplit() )
//						continue;
					MyField nextField = thisField.createField(location,activePiece);			
					// System.out.println( nextField.toString() );
					MyField treeField = null;
					if ( depth < pieces.length-2 || !multipleSolutions )
						treeField = (MyField) nextTree.find( nextField );
					if ( treeField != null )
					{
						duplicates += 1;
						treeField.setPaths( treeField.getPaths() + nextField.getPaths() );
						if ( debug )
						{
							System.out.println("FOUND DUPLICATE + " + duplicates + " ! " + "( " + thisQueue.currID + " / " + thisQueue.lastID + " )");
							System.out.println("ORIGINAL: " + "\n" + treeField.ancestorString() );
							System.out.println( "DUPLICATE: " + "\n" + nextField.ancestorString() );
						}
					}
					else
					{
						nextQueue.add( nextField );
						nextTree.insert( nextField );
						if ( debug && thisQueue.lastID % 10 == 0 )
							System.out.println( "( " + thisQueue.currID + " / " + thisQueue.lastID + " )" + " , " + duplicates );	
					}
				}
			} // <--
		}
		mergings[depth] = duplicates;
	}
	
	public void execute()
	{
		for ( int i = 0; i < pieces.length-1; i++ ) // pieces.length-1
		{
			long start = System.currentTimeMillis();
			process(i);
			long end = System.currentTimeMillis();
			Queue<MyField> nextQueue = queue[i+1];
			queue[i] = null; // freeing memory-usage
			System.out.println("depth " + i + " finished in " + (end - start) + " ms , valid fields = " + nextQueue.lastID + " , mergings = " + mergings[i] + " , memory = " + getMemory()/1024 );
		}
	}
	
    private static long getMemory()
    {
        Runtime runtime = Runtime.getRuntime();
        return runtime.totalMemory() - runtime.freeMemory();
    }
    
	public void statistics()
	{
		Queue<MyField> finalQueue = queue[pieces.length-1];
		finalQueue.reset();
		int numSolutions = 0; int sumPaths = 0;
		while ( finalQueue.hasNext() )
		{
			MyField field = finalQueue.next();
			if ( field.isEmpty() )
			{
				numSolutions += 1;
				sumPaths += field.getPaths();
				char c = MyField.shapeToChar( field.getPiece() );
				System.out.println( "\n" + "Found a solution with " + field.getPaths() + " different paths (" + c + " on hold)");
				System.out.println( field.ancestorString() );
			}
		}
		if ( numSolutions > 0 )
			System.out.println( "found solutions with " + numSolutions + " different pieces on hold and " + sumPaths + " paths in total" );
		else
			System.out.println("NO SOLUTION found :(" );
	}
		
	public static void main1(String[] args)
	{
		if ( args.length == 0 || args[0].length() != 11 )
		{
			System.out.println( "first parameter must be a word consisting of 11 letters e.g. JIZLOTSLITO");
			return;
		}
		String str = args[0].toUpperCase();
		short[] pieces = new short[ str.length() ];
		for ( int i = 0; i < str.length(); i++ )
		{
			char c = str.charAt(i);
			pieces[i] = (short) MyField.charToShape(c);
			if ( pieces[i] == MyField.piece_Invalid )
			{
				System.out.println( "only the letters I, T, O, L, J, S, Z, _ are valid for the first parameter");
				return;
			}
			else if ( i > 0 && i < 10 && pieces[i] == MyField.piece_Unknown ) 
			{
				System.out.println( "the letter _ is only valid at the start and at the end of the word");
				return;
			}
			else if ( i == 10 && pieces[0] == MyField.piece_Unknown && pieces[10] == MyField.piece_Unknown )
			{
				System.out.println( "the word can't contain _ two times, 10 pieces needed at least");
				return;
			}
		}
		if ( args.length >= 2 )
		{
			if ( args[1].equals("0") )
				check = check_Surface;
			else if ( args[1].equals("1") )
				check = check_Softdrop;
			else if ( args[1].equals("2") )
				check = check_Deepdrop;
		}
		String str2 = "";
		if ( check == check_Surface )
			str2 = " (using only harddrop)";
		else if ( check == check_Softdrop )
			str2 = " (using softdrop and kicks)";
		else if ( check == check_Deepdrop )
			str2 = " (using deepdrop)";
		if ( args.length >= 3 )
		{
			if ( args[2].equals("0") )
				nodeLimit = 1000000;
			else // if ( args[2].equals("1") )
				nodeLimit = 100000000;
		}
		String str3 = "";
		if ( nodeLimit <= 10000000 )
			str3 = " (field limit = " + nodeLimit + ")";
		else
			str3 = " (no field limit)";
		if ( args.length >= 4 )
		{
			if ( args[3].equals("0") )
				multipleSolutions = true;
			else
				multipleSolutions = false;
		}
		String str4 = "";
		if ( multipleSolutions )
			str4 = " (multiple solutions)";
		else
			str4 = " (one solution per hold)";
		System.out.println( "try to find perfect clears for the sequence " + str + str2 + str3 + str4 );
		boolean[][] matrix = new boolean[4][10];
		MyPerfectClearArr instance = new MyPerfectClearArr( matrix, pieces );
		long start = System.currentTimeMillis();
		instance.execute();
		long end = System.currentTimeMillis();
		instance.statistics();
		System.out.println("FINISHED the whole calculation in " + (end - start) + " ms" );
		
	}
	
	public static boolean[][] convertMirroredMatrix( int[][] intMatrix )
	{
		boolean[][] boolMatrix = new boolean[intMatrix.length][];
		for ( int y = 0; y < intMatrix.length; y++ )
		{
			int z = intMatrix.length - 1 - y;
			boolMatrix[z] = new boolean[intMatrix[y].length];
			for ( int x = 0; x < intMatrix[y].length; x++ )
				boolMatrix[z][x] = ( intMatrix[y][x] != 0 );
		}
		return boolMatrix;
	}
	
	@SuppressWarnings("unused")
	public static void test1()
	{
		int _ = 0;
		int X = 1;
		int[][] intMatrix = 
		{
			{_,_,_,_,_,_,_,_,_,_},
			{_,_,_,_,_,_,_,_,_,_},
			{X,_,_,X,X,_,_,X,X,X},
			{X,_,_,X,_,_,X,X,X,X},
		};
		boolean[][] matrix = convertMirroredMatrix( intMatrix );
		short I = MyField.piece_I;
		short T = MyField.piece_T;
		short O = MyField.piece_O;
		short L = MyField.piece_L;
		short J = MyField.piece_J;
		short S = MyField.piece_S;
		short Z = MyField.piece_Z;
		short[] pieces = new short[]{ O, I, S };
		MyField.goal = 2;
		MyPerfectClearArr instance = new MyPerfectClearArr( matrix, pieces );
		instance.execute();
		instance.statistics();
	}
	
	@SuppressWarnings("unused")
	public static void test2()
	{
		int _ = 0;
		int X = 1;
		int[][] intMatrix = 
		{
			{_,_,_,_,_,_,_,_,_,_},
			{_,_,_,_,_,_,_,_,_,_},
			{X,X,X,_,_,X,X,X,X,X},
			{X,X,_,_,X,X,X,X,X,X},
		};
		boolean[][] matrix = convertMirroredMatrix( intMatrix );
		short I = MyField.piece_I;
		short T = MyField.piece_T;
		short O = MyField.piece_O;
		short L = MyField.piece_L;
		short J = MyField.piece_J;
		short S = MyField.piece_S;
		short Z = MyField.piece_Z;
		MyField.calculateAdjustedKicks();
		MyField.reverseSteps = 4;
		MyField field = new MyFieldArr( matrix );
		System.out.println( field );
		short[] location = { S, 0, 0, 2 };
		System.out.println( "collision = " + field.collision(location) );
		boolean reachable = field.locationIsReachable(location);
		System.out.println( "reachable = " + reachable );
	}
	
	@SuppressWarnings("unused")
	public static void test3()
	{
		int _ = 0;
		int X = 1;
//		int[][] intMatrix = 
//		{
//			{_,_,_,_,_,_,_,_,_,_},
//			{_,_,_,_,_,_,_,_,_,_},
//			{X,X,_,_,_,_,X,X,X,X},
//			{X,X,X,_,_,_,_,X,X,X},
//		};
		int[][] intMatrix = 
		{
			{_,_,_,_,_,_,_,_,_,_},
			{_,_,_,_,_,_,_,_,_,_},
			{X,X,X,X,_,_,_,_,X,X},
			{X,X,X,_,_,_,_,X,X,X},
		};
		boolean[][] matrix = convertMirroredMatrix( intMatrix );
		short I = MyField.piece_I;
		short T = MyField.piece_T;
		short O = MyField.piece_O;
		short L = MyField.piece_L;
		short J = MyField.piece_J;
		short S = MyField.piece_S;
		short Z = MyField.piece_Z;
		MyField.calculateAdjustedKicks();
		MyField.reverseSteps = 4;
		MyField field = new MyFieldArr( matrix );
		System.out.println( field );
		short[] location = { I, 0, 0, 3 };
		System.out.println( "collision = " + field.collision(location) );
		boolean reachable = field.locationIsReachable(location);
		System.out.println( "reachable = " + reachable );
	}
	
	@SuppressWarnings("unused")
	public static void test4()
	{
		int _ = 0;
		int X = 1;
		int[][] intMatrix = 
		{
			{_,_,X,X,X,X,X,X,X,X},
			{_,_,_,X,X,X,X,X,X,X},
			{X,X,_,X,X,X,X,X,X,X},
			{X,_,_,X,X,X,X,X,X,X},
			{X,_,_,_,X,X,X,X,X,X},
			{X,X,_,X,X,X,X,X,X,X},
			{X,X,_,X,X,X,X,X,X,X},
		};
		boolean[][] matrix = convertMirroredMatrix( intMatrix );
		short I = MyField.piece_I;
		short T = MyField.piece_T;
		short O = MyField.piece_O;
		short L = MyField.piece_L;
		short J = MyField.piece_J;
		short S = MyField.piece_S;
		short Z = MyField.piece_Z;
		MyField.calculateAdjustedKicks();
		MyField.reverseSteps = 4;
		MyField field = new MyFieldArr( matrix );
		System.out.println( field );
		short[] location = { T, 2, 1, 1 };
		System.out.println( "collision = " + field.collision(location) );
		boolean reachable = field.locationIsReachable(location);
		System.out.println( "reachable = " + reachable );
	}
	
	@SuppressWarnings("unused")
	public static void test5()
	{
		int _ = 0;
		int X = 1;
		int[][] intMatrix = 
		{
			{_,_,_,_,_,_,_,_,_,_},
			{X,X,_,_,_,_,_,_,_,_},
			{X,X,X,_,_,_,X,_,_,_},
			{X,X,X,_,_,X,X,X,X,X},
			{X,X,X,_,_,X,X,X,X,X},
			{X,X,X,_,_,X,X,X,X,X},
			{X,X,X,_,_,_,X,X,X,X},
			{X,X,X,X,_,X,X,_,_,X},
		};
		boolean[][] matrix = convertMirroredMatrix( intMatrix );
		short I = FieldArr.piece_I;
		short T = FieldArr.piece_T;
		short O = FieldArr.piece_O;
		short L = FieldArr.piece_L;
		short J = FieldArr.piece_J;
		short S = FieldArr.piece_S;
		short Z = FieldArr.piece_Z;
		short[] pieces = new short[]{ O, T, L, I, J, Z, I, T, O, T };
		PerfectClearArr instance = new PerfectClearArr( matrix, pieces );
		instance.execute();
		instance.statistics();
	}
	
	@SuppressWarnings("unused")
	public static void test6()
	{
		int _ = 0;
		int X = 1;
		int[][] intMatrix = 
		{
			{X,X,X,X,X,_,_,_,_,_},
			{X,X,X,X,X,X,_,_,_,_},
			{X,X,X,X,X,X,X,_,_,_},
			{X,X,X,X,X,X,_,_,_,_},
			{_,_,_,_,_,X,X,X,X,X},
			{_,_,_,_,X,X,X,X,X,X},
			{_,_,_,X,X,X,X,X,X,X},
			{_,_,_,_,X,X,X,X,X,X},
		};
		boolean[][] matrix = convertMirroredMatrix( intMatrix );
		short I = FieldArr.piece_I;
		short T = FieldArr.piece_T;
		short O = FieldArr.piece_O;
		short L = FieldArr.piece_L;
		short J = FieldArr.piece_J;
		short S = FieldArr.piece_S;
		short Z = FieldArr.piece_Z;
		short[] pieces = new short[]{ I, Z, T, J, I, S, Z, T, O };
		PerfectClearArr instance = new PerfectClearArr( matrix, pieces );
		instance.execute();
		instance.statistics();
	}
	
	public static void main(String[] args)
	{
		main1(args);
		// test6();
	}
}

