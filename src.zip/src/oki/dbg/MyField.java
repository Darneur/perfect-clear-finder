package oki.dbg;

import oki.pc.FieldArr;


@SuppressWarnings({"rawtypes"})
public abstract class MyField implements Comparable
{
	public static final int piece_Unknown = 0,
							piece_T = 1,
							piece_L = 2,
							piece_J = 3,
							piece_S = 4,
							piece_Z = 5,
							piece_I = 6,
							piece_O = 7,
							piece_Invalid = 8;

	//public static int height = 4;
	public static final short width = 10;
	public static final short fullrow = (1<<width)-1;
	public static final short emptyrow = 0;
	public static int goal = 0;
	public static int reverseSteps = 3;
	public static boolean useKicks = true;
	
	private short piece; // piece on hold
	private MyField ancestor; // this field is created by dropping a certain piece in ancestor
	private int numAncestors; // number of all possible ancestors ( only first ancestor is saved )
	
	public MyField getAncestor(){ return ancestor; }
	public int getPaths(){ return numAncestors; }
	public short getPiece() { return piece; }
	
	public void setAncestor( MyField other ){ ancestor = other; }
	public void setPaths( int paths ){ numAncestors = paths; }
	public void setPiece( short piece ){ this.piece = piece; }
	
	public MyField( int height )
	{
		; // do nothing
	}
	
	public MyField( boolean[][] matrix )
	{
		setMatrix( matrix );
	}
	
	public MyField( MyField other )
	{
		this.piece = other.piece;
		this.ancestor = other.ancestor;
		this.numAncestors = other.numAncestors;
	}
	
	protected abstract MyField makeCopy();
	protected abstract int getHeight();
	protected abstract int compareMatrix( MyField other );
	protected abstract boolean filled( int row, int col );
	protected abstract void fillCell( int row, int col );
	protected abstract void makeEmpty( int row );
	protected abstract boolean isFull( int row );
	protected abstract void replaceWith( int oldRow, int newRow  );
	protected abstract void reduceHeight( int newHeight );
	
	public boolean isEmpty()
	{
		return ( getHeight() <= goal );
	}
	
	public int compareTo( Object obj )
	{ 
		MyField other = (MyField) obj;
		int height = this.getHeight();
		int height2 = other.getHeight();
		if ( height < height2 )
			return -1;
		else if ( height > height2 )
			return +1;
		int compare = compareMatrix(other);
		if ( compare < 0 )
			return -1;
		else if ( compare > 0 )
			return +1;
		short brick = other.piece; 
		if ( piece < brick )
			return -1;
		else if ( piece > brick )
			return +1;
		return 0;
	}
	
	public boolean equals( Object obj )
	{
		
		MyField other = (MyField) obj;
		if ( getHeight() != other.getHeight() )
			return false;
		if ( compareMatrix(other) != 0 )
			return false;
		if ( piece != other.piece )
			return false;
		return true;
	}
	
	public static int charToShape( char c )
	{
		c = Character.toUpperCase(c);
		if ( c == 'I' )
			return piece_I;
		else if ( c == 'T' )
			return piece_T;
		else if ( c == 'O' )
			return piece_O;
		else if ( c == 'L' )
			return piece_L;
		else if ( c == 'J' )
			return piece_J;
		else if ( c == 'S' )
			return piece_S;
		else if ( c == 'Z' )
			return piece_Z;
		else if ( c == '_' )
			return piece_Unknown;
		else
			return piece_Invalid;
	}
	
	public static char shapeToChar( int piece )
	{
		if ( piece == MyField.piece_I )
			return 'I';
		else if ( piece == MyField.piece_T )
			return 'T';
		else if ( piece == MyField.piece_O )
			return 'O';
		else if ( piece == MyField.piece_L )
			return 'L';
		else if ( piece == MyField.piece_J )
			return 'J';
		else if ( piece == MyField.piece_S )
			return 'S';
		else if ( piece == MyField.piece_Z )
			return 'Z';
		else if ( piece == FieldArr.piece_Unknown )
			return '_';
		else
			return '?';
	}
	
	public boolean collision( short[] location )
	{
		return collision( location[0], location[1], location[2], location[3] );
	}
	
	protected boolean collision( int piece, int dir, int row, int col )
	{
		if ( piece == piece_T )
		{
			if ( dir == 0 ) // north T piece
			{
				if ( filled(row+1,col+1) )
					return true;
				if ( filled(row,col+2) )
					return true;
				if ( filled(row,col+1) )
					return true;
				if ( filled(row,col) )
					return true;
			}
			else if ( dir == 1 ) // east T piece
			{
				if ( filled(row+1,col+1) )
					return true;
				if ( filled(row,col) )
					return true;
				if ( filled(row+1,col) )
					return true;
				if ( filled(row+2,col) )
					return true;
			}
			else if ( dir == 2 ) // south T piece
			{
				if ( filled(row+1,col+2) )
					return true;
				if ( filled(row+1,col+1) )
					return true;
				if ( filled(row+1,col) )
					return true;
				if ( filled(row,col+1) )
					return true;
			}
			else if ( dir == 3 ) // west T piece
			{
				if ( filled(row,col+1) )
					return true;
				if ( filled(row+1,col+1) )
					return true;
				if ( filled(row+2,col+1) )
					return true;
				if ( filled(row+1,col) )
					return true;
			}
		}
		else if ( piece == piece_L )
		{
			if ( dir == 0 ) // north L piece
			{
				if ( filled(row+1,col+2) )
					return true;
				if ( filled(row,col+2) )
					return true;
				if ( filled(row,col+1) )
					return true;
				if ( filled(row,col) )
					return true;
			}
			else if ( dir == 1 ) // east L piece
			{
				if ( filled(row,col+1) )
					return true;
				if ( filled(row,col) )
					return true;
				if ( filled(row+1,col) )
					return true;
				if ( filled(row+2,col) )
					return true;
			}
			else if ( dir == 2 ) // south L piece
			{
				if ( filled(row+1,col+2) )
					return true;
				if ( filled(row+1,col+1) )
					return true;
				if ( filled(row+1,col) )
					return true;
				if ( filled(row,col) )
					return true;
			}
			else if ( dir == 3 ) // west L piece
			{
				if ( filled(row,col+1) )
					return true;
				if ( filled(row+1,col+1) )
					return true;
				if ( filled(row+2,col+1) )
					return true;
				if ( filled(row+2,col) )
					return true;
			}
		}
		else if ( piece == piece_J )
		{
			if ( dir == 0 ) // north J piece
			{
				if ( filled(row+1,col) )
					return true;
				if ( filled(row,col) )
					return true;
				if ( filled(row,col+1) )
					return true;
				if ( filled(row,col+2) )
					return true;
			}
			else if ( dir == 1 ) // east J piece
			{
				if ( filled(row,col) )
					return true;
				if ( filled(row+1,col) )
					return true;
				if ( filled(row+2,col) )
					return true;
				if ( filled(row+2,col+1) )
					return true;
			}
			else if ( dir == 2 ) // south J piece
			{
				if ( filled(row+1,col) )
					return true;
				if ( filled(row+1,col+1) )
					return true;
				if ( filled(row+1,col+2) )
					return true;
				if ( filled(row,col+2) )
					return true;
			}
			else if ( dir == 3 ) // west J piece
			{
				if ( filled(row,col) )
					return true;
				if ( filled(row,col+1) )
					return true;
				if ( filled(row+1,col+1) )
					return true;
				if ( filled(row+2,col+1) )
					return true;
			}			
		}
		else if ( piece == piece_S )
		{
			if ( dir == 0 || dir == 2 ) // horizontal S piece
			{
				if ( filled(row+1,col+2) )
					return true;
				if ( filled(row+1,col+1) )
					return true;
				if ( filled(row,col+1) )
					return true;
				if ( filled(row,col) )
					return true;
			}
			else if ( dir == 1 || dir == 3 ) // vertical S piece
			{
				if ( filled(row,col+1) )
					return true;
				if ( filled(row+1,col+1) )
					return true;
				if ( filled(row+1,col) )
					return true;
				if ( filled(row+2,col) )
					return true;
			}
		}
		else if ( piece == piece_Z )
		{
			if ( dir == 0 || dir == 2 ) // horizontal Z piece
			{
				if ( filled(row+1,col) )
					return true;
				if ( filled(row+1,col+1) )
					return true;
				if ( filled(row,col+1) )
					return true;
				if ( filled(row,col+2) )
					return true;
			}
			else if ( dir == 1 || dir == 3 ) // vertical Z piece
			{
				if ( filled(row,col) )
					return true;
				if ( filled(row+1,col) )
					return true;
				if ( filled(row+1,col+1) )
					return true;
				if ( filled(row+2,col+1) )
					return true;
			}
		}
		else if ( piece == piece_I )
		{
			if ( dir == 0 || dir == 2 ) // horizontal I piece
			{
				if ( filled(row,col) )
					return true;
				if ( filled(row,col+1) )
					return true;
				if ( filled(row,col+2) )
					return true;
				if ( filled(row,col+3) )
					return true;
			}
			else if ( dir == 1 || dir == 3 ) // vertical I piece
			{
				if ( filled(row,col) )
					return true;
				if ( filled(row+1,col) )
					return true;
				if ( filled(row+2,col) )
					return true;
				if ( filled(row+3,col) )
					return true;
			}
		}
		else if ( piece == piece_O )
		{
			if ( dir <= 4 ) // every O piece
			{
				if ( filled(row+1,col) )
					return true;
				if ( filled(row+1,col+1) )
					return true;
				if ( filled(row,col+1) )
					return true;
				if ( filled(row,col) )
					return true;
			}
		}		
		return false;
	}
	
	public void insertPiece( short[] location )
	{
		insertPiece( location[0], location[1], location[2], location[3] );
	}
	
	protected void insertPiece( int piece, int dir, int row, int col )
	{
		if ( piece == piece_T )
		{		
			if ( dir == 0 ) // north T piece
			{
				fillCell(row+1,col+1);
				fillCell(row,col+2);
				fillCell(row,col+1);
				fillCell(row,col);
			}
			else if ( dir == 1 ) // east T piece
			{
				fillCell(row+1,col+1);
				fillCell(row,col);
				fillCell(row+1,col);
				fillCell(row+2,col);
			}
			else if ( dir == 2 ) // south T piece
			{
				fillCell(row+1,col+2);
				fillCell(row+1,col+1);
				fillCell(row+1,col);
				fillCell(row,col+1);
			}
			else if ( dir == 3 ) // west T piece
			{
				fillCell(row,col+1);
				fillCell(row+1,col+1);
				fillCell(row+2,col+1);
				fillCell(row+1,col);
			}			
		}
		else if ( piece == piece_L )
		{		
			if ( dir == 0 ) // north L piece
			{
				fillCell(row+1,col+2);
				fillCell(row,col+2);
				fillCell(row,col+1);
				fillCell(row,col);
			}
			else if ( dir == 1 ) // east L piece
			{
				fillCell(row,col+1);
				fillCell(row,col);
				fillCell(row+1,col);
				fillCell(row+2,col);
			}
			else if ( dir == 2 ) // south L piece
			{
				fillCell(row+1,col+2);
				fillCell(row+1,col+1);
				fillCell(row+1,col);
				fillCell(row,col);
			}

			else if ( dir == 3 ) // west L piece
			{

				fillCell(row,col+1);
				fillCell(row+1,col+1);
				fillCell(row+2,col+1);
				fillCell(row+2,col);
			}			
		}
		else if ( piece == piece_J )
		{		
			if ( dir == 0 ) // north J piece
			{
				fillCell(row+1,col);
				fillCell(row,col);
				fillCell(row,col+1);
				fillCell(row,col+2);
			}
			else if ( dir == 1 ) // east J piece
			{
				fillCell(row,col);
				fillCell(row+1,col);
				fillCell(row+2,col);
				fillCell(row+2,col+1);
			}
			
			else if ( dir == 2 ) // south J piece
			{
				fillCell(row+1,col);
				fillCell(row+1,col+1);
				fillCell(row+1,col+2);
				fillCell(row,col+2);
			}
			else if ( dir == 3 ) // west J piece
			{
				fillCell(row,col);
				fillCell(row,col+1);
				fillCell(row+1,col+1);
				fillCell(row+2,col+1);
			}
		}
		else if ( piece == piece_S )
		{		
			if ( dir == 0 || dir == 2 ) // horizontal S piece
			{
				fillCell(row+1,col+2);
				fillCell(row+1,col+1);
				fillCell(row,col+1);
				fillCell(row,col);
			}
			else if ( dir == 1 || dir == 3 ) // vertical S piece
			{
				fillCell(row,col+1);
				fillCell(row+1,col+1);
				fillCell(row+1,col);
				fillCell(row+2,col);
			}
		}
		else if ( piece == piece_Z )
		{
			if ( dir == 0 || dir == 2 ) // horizontal Z piece
			{
				fillCell(row+1,col);
				fillCell(row+1,col+1);
				fillCell(row,col+1);
				fillCell(row,col+2);
			}
			else if ( dir == 1 || dir == 3 ) // vertical Z piece
			{
				fillCell(row,col);
				fillCell(row+1,col);
				fillCell(row+1,col+1);
				fillCell(row+2,col+1);
			}
		}
		else if ( piece == piece_I )
		{
			if ( dir == 0 || dir == 2 ) // horizontal I piece
			{
				fillCell(row,col);
				fillCell(row,col+1);
				fillCell(row,col+2);
				fillCell(row,col+3);
			}
			else if ( dir == 1 || dir == 3 ) // vertical I piece
			{
				fillCell(row,col);
				fillCell(row+1,col);
				fillCell(row+2,col);
				fillCell(row+3,col);
			}
		}
		else if ( piece == piece_O )
		{
			if ( dir <= 4 ) // every O piece
			{
				fillCell(row+1,col);
				fillCell(row+1,col+1);
				fillCell(row,col+1);
				fillCell(row,col);
			}
		}
	}
	
	public void clearLines()
	{
		int height = getHeight();
		int clears = 0;
		for ( int y = 0; y < height; y++ )
		{
			while ( y+clears < height && isFull(y+clears) )
				clears += 1;
			if ( y + clears >= height )
				makeEmpty(y);
			else if ( clears > 0 )
				replaceWith(y, y+clears );
		}
		if ( clears > 0 )
			reduceHeight( height-clears );
	}
	
	public void drop( int piece, int dir, int row, int col )
	{
		while ( row > 0 && !collision(piece, dir, row-1, col) )
			row -= 1;
		insertPiece(piece,dir,row,col);
		clearLines();
	}
	
	// matrix[row][col] whereas row = 0 means bottom, and col = 0 means left side
	public boolean[][] getMatrix()
	{
		int height = getHeight();
		boolean[][] matrix = new boolean[height][width];
		for ( int row = 0; row < height; row++ )
			for ( int col = 0; col < width; col++ )
				matrix[row][col] = filled(row,col);
		return matrix;
	}
	
	// matrix[row][col] whereas row = 0 means bottom, and col = 0 means left side
	public void setMatrix( boolean[][] matrix )
	{
		int height = getHeight();
		for ( int row = 0; row < height; row++ )
			makeEmpty(row);
		for ( int row = 0; row < height; row++ )
			for ( int col = 0; col < width; col++ )
				if ( matrix[row][col] == true )
					fillCell(row,col);
	}
	
	// public abstract String toString();
	public String toString()
	{
		int height = getHeight();
		String str = "";
		for ( int row = height-1; row >= 0; row-- )
		{
			for ( int col = 0; col < width; col++ )
			{
				if ( filled(row,col) )
					str += "X";
				else
					str += "_";
			}
			str = str + "\n";	
		}
		str += "hold = " + shapeToChar( piece );
		str += " , paths  = " + numAncestors;
		return str;
	}
	
	
	public String ancestorString()
	{
		if ( ancestor != null )
			return ancestor.ancestorString() + "\n" + this.toString();
		else
			return this.toString();
	}
	
	// location[0] = piece
	// location[1] = direction
	// location[2] = row
	// location[3] = column
	public short[] resetLocation( short nextPiece )
	{
		short[] location = new short[4];
		if ( nextPiece != piece_Unknown )
			location[0] = nextPiece;
		else
			location[0] = piece;
		location[1] = 0;
		location[2] = 0;
		location[3] = -1;
		return location;
	}
	
	public MyField createField( short[] location, short nextPiece )
	{
		MyField copy = makeCopy();
		copy.insertPiece( location[0], location[1], location[2], location[3] );
		copy.clearLines();
		copy.ancestor = this;
		if ( location[0] == this.piece ) // used hold
			copy.piece = nextPiece;
		return copy;
	}
	
	// increase row -> increase column -> increase direction -> use hold
	public boolean getNextLocation( short[] location )
	{
		short piece = location[0];
		short dir = location[1];
		int directions;
		if ( piece == piece_O )
			directions = 1;
		else if ( piece == piece_I || piece == piece_S || piece == piece_Z )
			directions = 2;
		else
			directions = 4;
		if ( dir == directions )
		{
			if ( piece == this.piece || this.piece == piece_Unknown )
				return false;
			location[0] = this.piece;
			location[1] = 0;
			return getNextLocation( location );
		}
		short row = location[2];
		short col = location[3];
		int topRow = getHeight();
		int rightCol = MyField.width;
		if ( piece == piece_O )
		{
			rightCol -= 2;
			topRow -= 2;
		}
		else if ( piece == piece_I )
		{
			if ( dir == 0 || dir == 2 )
			{
				rightCol -= 4;
				topRow -= 1;
			}
			else
			{
				rightCol -= 1;
				topRow -= 4;				
			}
		}
		else // piece = S,Z,T,L,J
		{
			if ( dir == 0 || dir == 2 )
			{
				rightCol -= 3;
				topRow -= 2;
			}
			else
			{
				rightCol -= 2;
				topRow -= 3;
			}
		}
		if ( topRow < 0 )
		{
			location[1] += 1;
			location[2] = 0;
			location[3] = -1;
			return getNextLocation( location );
		}
		while( true )
		{
			if ( col < rightCol )
				col += 1;
			else if ( row < topRow )
			{
				row += 1;
				col = 0;
			}
			else
			{
				location[1] += 1;
				location[2] = 0;
				location[3] = -1;
				return getNextLocation( location );
			}
			if ( !collision(piece,dir,row,col) && ( row == 0 || collision(piece,dir,row-1,col) ) )
			{
				location[2] = row;
				location[3] = col;
				return true;
			}	
		}
	}
	
	public boolean locationOnSurface( short[] location )
	{
		return locationOnSurface( location[0], location[1], location[2], location[3] );
	}
	
	private boolean locationOnSurface( int piece, int dir, int row, int col )
	{
		int height = getHeight();
		while ( ++row < height )
		{
			if ( collisionOutside(piece, dir, row, col) )
				return false;
		}
		return true;
	}
	
	// ############ check overhangs and kicks ################
	
	public static final int[][][] SRSKICK_R =
	{
		{{ 0, 0},{-1, 0},{-1, 1},{ 0,-2},{-1,-2}},	// 0>>1
		{{ 0, 0},{ 1, 0},{ 1,-1},{ 0, 2},{ 1, 2}},	// 1>>2
		{{ 0, 0},{ 1, 0},{ 1, 1},{ 0,-2},{ 1,-2}},	// 2>>3
		{{ 0, 0},{-1, 0},{-1,-1},{ 0, 2},{-1, 2}},	// 3>>0
	};
	public static final int[][][] SRSKICK_L  =
	{
		{{ 0, 0},{ 1, 0},{ 1, 1},{ 0,-2},{ 1,-2}},	// 0>>3
		{{ 0, 0},{ 1, 0},{ 1,-1},{ 0, 2},{ 1, 2}},	// 1>>0
		{{ 0, 0},{-1, 0},{-1, 1},{ 0,-2},{-1,-2}},	// 2>>1
		{{ 0, 0},{-1, 0},{-1,-1},{ 0, 2},{-1, 2}},	// 3>>2
	};
	public static final int[][][] SRSKICK_RI =
	{
		{{ 0, 0},{-2, 0},{ 1, 0},{-2,-1},{ 1, 2}},	// 0>>1
		{{ 0, 0},{-1, 0},{ 2, 0},{-1, 2},{ 2,-1}},	// 1>>2
		{{ 0, 0},{ 2, 0},{-1, 0},{ 2, 1},{-1,-2}},	// 2>>3
		{{ 0, 0},{ 1, 0},{-2, 0},{ 1,-2},{-2, 1}},	// 3>>0
	};
	public static final int[][][] SRSKICK_LI =
	{
		{{ 0, 0},{-1, 0},{ 2, 0},{-1, 2},{ 2,-1}},	// 0>>3
		{{ 0, 0},{ 2, 0},{-1, 0},{ 2, 1},{-1,-2}},	// 1>>0
		{{ 0, 0},{ 1, 0},{-2, 0},{ 1,-2},{-2, 1}},	// 2>>1
		{{ 0, 0},{-2, 0},{ 1, 0},{-2,-1},{ 1, 2}},	// 3>>2
	};
	
	static short[][] kick_RX, kick_LX;
	static short[][] kick_RY, kick_LY;
	static short[][] ikick_RX, ikick_LX;
	static short[][] ikick_RY, ikick_LY;
	
	private static int adjustLocationX( int dir, boolean tPiece )
	{
		if ( tPiece )
		{
			if ( dir == 1 )
				return -1;
			else
				return 0;
		}
		else // I piece
		{
			if ( dir == 1 )
				return -2;
			else if ( dir == 3 )
				return -1;
			else
				return 0;
		}
	}
	
	private static int adjustLocationY( int dir, boolean tPiece )
	{
		if ( tPiece )
		{
			if ( dir == 0 )
				return -1;
			else
				return 0;
		}
		else // I piece
		{
			if ( dir == 0 )
				return -2;
			else if ( dir == 2 )
				return -1;
			else
				return 0;
		}
	}
	
	public static void calculateAdjustedKicks()
	{
		// T,L,J,S,Z kicks
		kick_RX = new short[4][];
		kick_RY = new short[4][];
		for ( int i = 0; i < 4; i++ )
		{
			int xi = adjustLocationX( i, true );
			int yi = adjustLocationY( i, true );
			int xj = adjustLocationX((i+1)%4, true ); // rotate right
			int yj = adjustLocationY((i+1)%4, true ); // rotate right
			kick_RX[i] = new short[SRSKICK_R[i].length];
			kick_RY[i] = new short[SRSKICK_R[i].length];
			for ( int k = 0; k < SRSKICK_R[i].length; k++ )
			{
				kick_RX[i][k] = (short) (xi - xj + SRSKICK_R[i][k][0]);
				kick_RY[i][k] = (short) (yi - yj + SRSKICK_R[i][k][1]);
			}	
		}
		kick_LX = new short[4][];
		kick_LY = new short[4][];
		for ( int i = 0; i < 4; i++ )
		{
			int xi = adjustLocationX( i, true );
			int yi = adjustLocationY( i, true );
			int xj = adjustLocationX((i+3)%4, true ); // rotate left
			int yj = adjustLocationY((i+3)%4, true ); // rotate left
			kick_LX[i] = new short[SRSKICK_L[i].length];
			kick_LY[i] = new short[SRSKICK_L[i].length];
			for ( int k = 0; k < SRSKICK_L[i].length; k++ )
			{
				kick_LX[i][k] = (short) (xi - xj + SRSKICK_L[i][k][0]);
				kick_LY[i][k] = (short) (yi - yj + SRSKICK_L[i][k][1]);
			}
		}
		// I piece kicks
		ikick_RX = new short[4][];
		ikick_RY = new short[4][];
		for ( int i = 0; i < 4; i++ )
		{
			int xi = adjustLocationX( i, false );
			int yi = adjustLocationY( i, false );
			int xj = adjustLocationX((i+1)%4, false ); // rotate right
			int yj = adjustLocationY((i+1)%4, false ); // rotate right
			ikick_RX[i] = new short[SRSKICK_RI[i].length];
			ikick_RY[i] = new short[SRSKICK_RI[i].length];
			for ( int k = 0; k < SRSKICK_RI[i].length; k++ )
			{
				ikick_RX[i][k] = (short) (xi - xj + SRSKICK_RI[i][k][0]);
				ikick_RY[i][k] = (short) (yi - yj + SRSKICK_RI[i][k][1]);
			}	
		}
		ikick_LX = new short[4][];
		ikick_LY = new short[4][];
		for ( int i = 0; i < 4; i++ )
		{
			int xi = adjustLocationX( i, false );
			int yi = adjustLocationY( i, false );
			int xj = adjustLocationX((i+3)%4, false ); // rotate left
			int yj = adjustLocationY((i+3)%4, false ); // rotate left
			ikick_LX[i] = new short[SRSKICK_LI[i].length];
			ikick_LY[i] = new short[SRSKICK_LI[i].length];
			for ( int k = 0; k < SRSKICK_LI[i].length; k++ )
			{
				ikick_LX[i][k] = (short) (xi - xj + SRSKICK_LI[i][k][0]);
				ikick_LY[i][k] = (short) (yi - yj + SRSKICK_LI[i][k][1]);
			}	
		}
	}
	
	public boolean collisionOutside( short[] location )
	{
		return collisionOutside( location[0], location[1], location[2], location[3] );
	}
	
	protected boolean collisionOutside(int piece, int dir, int row, int col)
	{
		if ( col < 0 || row < 0 )
			return true;
		int rightCol = width;
		if ( piece == piece_O )
			rightCol -= 2;
		else if ( piece == piece_I )
			if ( dir == 0 || dir == 2 )
				rightCol -= 4;
			else
				rightCol -= 1;
		else // piece = S,Z,T,L,J
			if ( dir == 0 || dir == 2 )
				rightCol -= 3;
			else
				rightCol -= 2;
		if ( col > rightCol )
			return true;
		int height = getHeight();
		if ( row >= height )
			return false;
		if ( piece == piece_T )
		{
			if ( dir == 0 ) // north T piece
			{
				if ( row+1 < height && filled(row+1,col+1) )
					return true;
				if ( filled(row,col+2) )
					return true;
				if ( filled(row,col+1) )
					return true;
				if ( filled(row,col) )
					return true;
			}
			else if ( dir == 1 ) // east T piece
			{
				if ( row+1 < height && filled(row+1,col+1) )
					return true;
				if ( filled(row,col) )
					return true;
				if ( row+1 < height && filled(row+1,col) )
					return true;
				if ( row+2 < height && filled(row+2,col) )
					return true;
			}
			else if ( dir == 2 ) // south T piece
			{
				if ( row+1 < height && filled(row+1,col+2) )
					return true;
				if ( row+1 < height && filled(row+1,col+1) )
					return true;
				if ( row+1 < height && filled(row+1,col) )
					return true;
				if ( filled(row,col+1) )
					return true;
			}
			else if ( dir == 3 ) // west T piece
			{
				if ( filled(row,col+1) )
					return true;
				if ( row+1 < height && filled(row+1,col+1) )
					return true;
				if ( row+2 < height && filled(row+2,col+1) )
					return true;
				if ( row+1 < height && filled(row+1,col) )
					return true;
			}
		}
		else if ( piece == piece_L )
		{
			if ( dir == 0 ) // north L piece
			{
				if ( row+1 < height && filled(row+1,col+2) )
					return true;
				if ( filled(row,col+2) )
					return true;
				if ( filled(row,col+1) )
					return true;
				if ( filled(row,col) )
					return true;
			}
			else if ( dir == 1 ) // east L piece
			{
				if ( filled(row,col+1) )
					return true;
				if ( filled(row,col) )
					return true;
				if ( row+1 < height && filled(row+1,col) )
					return true;
				if ( row+2 < height && filled(row+2,col) )
					return true;
			}
			else if ( dir == 2 ) // south L piece
			{
				if ( row+1 < height && filled(row+1,col+2) )
					return true;
				if ( row+1 < height && filled(row+1,col+1) )
					return true;
				if ( row+1 < height && filled(row+1,col) )
					return true;
				if ( filled(row,col) )
					return true;
			}
			else if ( dir == 3 ) // west L piece
			{
				if ( filled(row,col+1) )
					return true;
				if ( row+1 < height && filled(row+1,col+1) )
					return true;
				if ( row+2 < height && filled(row+2,col+1) )
					return true;
				if ( row+2 < height && filled(row+2,col) )
					return true;
			}
		}
		else if ( piece == piece_J )
		{
			if ( dir == 0 ) // north J piece
			{
				if ( row+1 < height && filled(row+1,col) )
					return true;
				if ( filled(row,col) )
					return true;
				if ( filled(row,col+1) )
					return true;
				if ( filled(row,col+2) )
					return true;
			}
			else if ( dir == 1 ) // east J piece
			{
				if ( filled(row,col) )
					return true;
				if ( row+1 < height && filled(row+1,col) )
					return true;
				if ( row+2 < height && filled(row+2,col) )
					return true;
				if ( row+2 < height && filled(row+2,col+1) )
					return true;
			}
			else if ( dir == 2 ) // south J piece
			{
				if ( row+1 < height && filled(row+1,col) )
					return true;
				if ( row+1 < height && filled(row+1,col+1) )
					return true;
				if ( row+1 < height && filled(row+1,col+2) )
					return true;
				if ( filled(row,col+2) )
					return true;
			}
			else if ( dir == 3 ) // west J piece
			{
				if ( filled(row,col) )
					return true;
				if ( filled(row,col+1) )
					return true;
				if ( row+1 < height && filled(row+1,col+1) )
					return true;
				if ( row+2 < height && filled(row+2,col+1) )
					return true;
			}			
		}
		else if ( piece == piece_S )
		{
			if ( dir == 0 || dir == 2 ) // horizontal S piece
			{
				if ( row+1 < height && filled(row+1,col+2) )
					return true;
				if ( row+1 < height && filled(row+1,col+1) )
					return true;
				if ( filled(row,col+1) )
					return true;
				if ( filled(row,col) )
					return true;
			}
			else if ( dir == 1 || dir == 3 ) // vertical S piece
			{
				if ( filled(row,col+1) )
					return true;
				if ( row+1 < height && filled(row+1,col+1) )
					return true;
				if ( row+1 < height && filled(row+1,col) )
					return true;
				if ( row+2 < height && filled(row+2,col) )
					return true;
			}
		}
		else if ( piece == piece_Z )
		{
			if ( dir == 0 || dir == 2 ) // horizontal Z piece
			{
				if ( row+1 < height && filled(row+1,col) )
					return true;
				if ( row+1 < height && filled(row+1,col+1) )
					return true;
				if ( filled(row,col+1) )
					return true;
				if ( filled(row,col+2) )
					return true;
			}
			else if ( dir == 1 || dir == 3 ) // vertical Z piece
			{
				if ( filled(row,col) )
					return true;
				if ( row+1 < height && filled(row+1,col) )
					return true;
				if ( row+1 < height && filled(row+1,col+1) )
					return true;
				if ( row+2 < height && filled(row+2,col+1) )
					return true;
			}
		}
		else if ( piece == piece_I )
		{
			if ( dir == 0 || dir == 2 ) // horizontal I piece
			{
				if ( filled(row,col) )
					return true;
				if ( filled(row,col+1) )
					return true;
				if ( filled(row,col+2) )
					return true;
				if ( filled(row,col+3) )
					return true;
			}
			else if ( dir == 1 || dir == 3 ) // vertical I piece
			{
				if ( filled(row,col) )
					return true;
				if ( row+1 < height && filled(row+1,col) )
					return true;
				if ( row+2 < height && filled(row+2,col) )
					return true;
				if ( row+3 < height && filled(row+3,col) )
					return true;
			}
		}
		else if ( piece == piece_O )
		{
			if ( dir <= 4 ) // every O piece
			{
				if ( row+1 < height && filled(row+1,col) )
					return true;
				if ( row+1 < height && filled(row+1,col+1) )
					return true;
				if ( filled(row,col+1) )
					return true;
				if ( filled(row,col) )
					return true;
			}
		}		
		return false;
	}
	
	public boolean locationIsReachable( short[] location )
	{
		if ( locationOnSurface(location) )
			return true;
		int piece = location[0];
		if ( piece == piece_S || piece == piece_Z || piece == piece_I )
		{
			boolean reachable = reverseReachable( location[0], location[1], location[2], location[3], location, 0 );
			if ( !reachable )
			{
				location[1] = (short) (( location[1] + 2 ) % 4);  // rotate by 180 degrees
				reachable = reverseReachable( location[0], location[1], location[2], location[3], location, 0 );
				location[1] = (short) (( location[1] + 2 ) % 4);
			}
			return reachable;
		}
		else
			return reverseReachable( location[0], location[1], location[2], location[3], location, 0 );	
	}
	
	private boolean reverseReachable( int piece, int dir, int row, int col, short[] origin, int iteration )
	{
		if ( dir == origin[1] && row == origin[2] && col == origin[3] && iteration != 0 )
			return false;
		// System.out.println( "dir = " + dir + " , row = " + row + " , col = " + col );
		if ( locationOnSurface( piece, dir, row, col ) )
			return true;
		if ( iteration >= reverseSteps )
			return false;
		if ( !collisionOutside(piece, dir, row, col-1) ) // move left
			if ( reverseReachable(piece, dir, row, col-1, origin, iteration+1) )
				return true;
		if ( !collisionOutside(piece, dir, row, col+1) ) // move right
			if ( reverseReachable(piece, dir, row, col+1, origin, iteration+1) )
				return true;
		if ( !collisionOutside(piece, dir, row+1, col) ) // move up
			if ( reverseReachable(piece, dir, row+1, col, origin, iteration+1) )
				return true;
		if ( piece == piece_O )
			return false;
		short[][] kick_RX, kick_RY, kick_LX, kick_LY;
		if ( piece == piece_I )
		{
			kick_RX = MyField.ikick_RX;
			kick_RY = MyField.ikick_RY;
			kick_LX = MyField.ikick_LX;
			kick_LY = MyField.ikick_LY;
		}
		else
		{
			kick_RX = MyField.kick_RX;
			kick_RY = MyField.kick_RY;
			kick_LX = MyField.kick_LX;
			kick_LY = MyField.kick_LY;
		}
		int newDir, newRow, newCol;
		newDir = ( dir+1 ) % 4; // rotate right
		for ( int i = 0; i < kick_LX[newDir].length; i++ )
		{
			if ( i == 1 && !useKicks )
				break;
			newCol = col - kick_LX[newDir][i];
			newRow = row - kick_LY[newDir][i];
			// System.out.println( "cw kick " + i + " : dir = " + newDir + " , row = " + newRow + " , col = " + newCol );
			if ( collisionOutside(piece, newDir, newRow, newCol) )
				continue;
			// test if backwards kick leads to this location
			int backRow = -9;
			int backCol = -9;
			for ( int j = 0; j < kick_RX[newDir].length; j++ )
			{
				backCol = newCol + kick_LX[newDir][j];
				backRow = newRow + kick_LY[newDir][j];
				if ( !collisionOutside(piece, dir, backRow, backCol) )
					break;
			}
			// System.out.println( "back kick " + i + " : dir = " + dir + " , row = " + backRow + " , col = " + backCol );
			if ( backRow == row && backCol == col )
			{
				// System.out.println( "accepted kick " + i + " : dir = " + newDir + " , row = " + newRow + " , col = " + newCol );
				if ( reverseReachable(piece, newDir, newRow, newCol, origin, iteration+1) )
					return true;
			}
		}
		newDir = ( dir+3 ) % 4; // rotate left
		for ( int i = 0; i < kick_RX[newDir].length; i++ )
		{
			if ( i == 1 && !useKicks )
				break;
			newCol = col - kick_RX[newDir][i];
			newRow = row - kick_RY[newDir][i];
			// System.out.println( "ccw kick " + i + " : dir = " + newDir + " , row = " + newRow + " , col = " + newCol );
			if ( collisionOutside(piece, newDir, newRow, newCol) )
				continue;
			// test if backwards kick leads to this location
			int backRow = -9;
			int backCol = -9;
			for ( int j = 0; j < kick_RX[newDir].length; j++ )
			{
				backCol = newCol + kick_RX[newDir][j];
				backRow = newRow + kick_RY[newDir][j];
				if ( !collisionOutside(piece, dir, backRow, backCol) )
					break;
			}
			// System.out.println( "back kick " + i + " : dir = " + dir + " , row = " + backRow + " , col = " + backCol );
			if ( backRow == row && backCol == col )
			{
				// System.out.println( "accepted kick " + i + " : dir = " + newDir + " , row = " + newRow + " , col = " + newCol );
				if ( reverseReachable(piece, newDir, newRow, newCol, origin, iteration+1) )
					return true;
			}
		}
		return false;
	}
	
	public boolean hasOddSplit()
	{
		int height = getHeight();
		for ( int col = 0; col < width-1; col++ )
		{
			boolean split = true;
			for ( int row = 0; row < height; row++ )
			{
				if ( !filled(row,col) && !filled(row,col+1) )
				{
					split = false;
					break;
				}
			}
			if ( split )
			{ // count empty cells in left part
				int empty = 0;
				for ( int col2 = 0; col2 <= col; col2++ )
					for ( int row2 = 0; row2 < height; row2++ )
						if ( !filled(row2,col2) )
							empty += 1;
				if ( empty % 4 != 0 )
					return true;
			}
		}
		return false;
	}
	
	// reverse engineer
	public short[] reverseMove( short nextPiece )
	{
		MyField father = ancestor.makeCopy();
		if ( this.piece == nextPiece )
			nextPiece = father.piece;
		else
			father.piece = nextPiece;
			
		short[] location = father.resetLocation( nextPiece );
		while ( true )
		{
			MyField test = createField( location, nextPiece );
			if ( test.compareMatrix(this)==0 && MyPerfectClearArr.acceptMove(father, location) )
				return location;
			if ( !father.getNextLocation(location) )
				return null;
		}
	}
}
