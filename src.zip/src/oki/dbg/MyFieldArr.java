package oki.dbg;

public class MyFieldArr extends MyField
{
	short[] field; // each index stands for a row encrypted to a short
	
	public MyFieldArr( short height )
	{
		super(height);
		field = new short[height];
	}
	
	public MyFieldArr( boolean[][] matrix )
	{
		super(matrix.length);
		field = new short[ matrix.length ];
		setMatrix( matrix );
	}
	
	public MyFieldArr( MyFieldArr other )
	{
		super(other);
		int height = other.field.length;
		field = new short[height];
		for ( int row = 0; row < height; row++ )
			this.field[row] = other.field[row];
	}
	
	protected MyField makeCopy()
	{
		return new MyFieldArr( this );
	}
	
	protected int getHeight()
	{
		return field.length;
	}
	
	protected int compareMatrix( MyField obj )
	{
		MyFieldArr other = (MyFieldArr) obj;
		short[] matrix = other.field;
		for ( int y = 0; y < field.length; y++ )
			if ( field[y] < matrix[y] )
				return -1;
			else if ( field[y] > matrix[y] )
				return +1;
		return 0;
	}
	
	protected boolean filled( int row, int col )
	{
		return ( (field[row]>>col)&1) != 0;
	}
	
//	protected short getRow( int row )
//	{
//		return field[row];
//	}
	
	protected void fillCell( int row, int col )
	{
		field[row] ^= 1 << col;
	}
	
	protected void makeEmpty( int row )
	{
		field[row] = emptyrow;
	}
	
	protected boolean isFull( int row )
	{
		return ( field[row] == fullrow );
	}
	
	protected void replaceWith( int oldRow, int newRow  )
	{
		field[oldRow] = field[newRow];
	}
	
	protected void reduceHeight( int newHeight )
	{
		int height = newHeight;
		short[] copy = new short[height];
		for ( int y = 0; y < height; y++ )
			copy[y] = field[y];
		field = copy;
	}
}
