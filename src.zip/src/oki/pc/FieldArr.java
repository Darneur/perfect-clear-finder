package oki.pc;

@SuppressWarnings({"rawtypes"})
public class FieldArr implements Comparable
{
	public static final int piece_Unknown = 0,
							piece_T = 1,
							piece_L = 2,
							piece_J = 3,
							piece_S = 4,
							piece_Z = 5,
							piece_I = 6,
							piece_O = 7,
							piece_Invalid = 8;

	//public static int height = 4;
	public static final int width = 10;
	public static final int fullrow = (1<<width)-1;
	public static final int emptyrow = 0;
	public static int goal = 0;
	public static int reverseSteps = 3;
	public static boolean useKicks = true;
	
	short[] field; // each index stands for a row encrypted to a short
	byte piece; // piece on hold
	FieldArr ancestor; // this field is created by dropping a certain piece in ancestor
	int paths; // number of all possible paths leading to this field
	byte overhangs; // number of overhang cells summed up during the path
	
	public FieldArr( int height )
	{
		field = new short[height];
	}
	
	public FieldArr( boolean[][] matrix )
	{
		field = new short[ matrix.length ];
		setMatrix( matrix );
	}
	
	public FieldArr( FieldArr other )
	{
		int height = other.field.length;
		field = new short[height];
		for ( int row = 0; row < height; row++ )
			this.field[row] = other.field[row];
		this.piece = other.piece;
		this.ancestor = other.ancestor;
		this.paths = other.paths;
		this.overhangs = other.overhangs;
	}
	
	public int compareTo( Object obj ) 
	{
		FieldArr other = (FieldArr) obj;
		short[] matrix = other.field;
		int height = field.length;
		int height2 = matrix.length;
		if ( height < height2 )
			return -1;
		else if ( height > height2 )
			return +1;
		for ( int y = 0; y < height; y++ )
			if ( field[y] < matrix[y] )
				return -1;
			else if ( field[y] > matrix[y] )
				return +1;
		short brick = other.piece; 
		if ( piece < brick )
			return -1;
		else if ( piece > brick )
			return +1;
		return 0;
	}
	
	public boolean sameMatrix( FieldArr other )
	{
		short[] matrix = other.field;
		int height = field.length;
		int height2 = matrix.length;
		if ( height != height2 )
			return false;
		for ( int y = 0; y < height; y++ )
			if ( field[y] != matrix[y] )
				return false;
		return true;
	}
	
	public boolean isEmpty()
	{
		return ( field.length <= goal );
	}
	
	public static int charToShape( char c )
	{
		c = Character.toUpperCase(c);
		if ( c == 'I' )
			return piece_I;
		else if ( c == 'T' )
			return piece_T;
		else if ( c == 'O' )
			return piece_O;
		else if ( c == 'L' )
			return piece_L;
		else if ( c == 'J' )
			return piece_J;
		else if ( c == 'S' )
			return piece_S;
		else if ( c == 'Z' )
			return piece_Z;
		else if ( c == '_' )
			return piece_Unknown;
		else
			return piece_Invalid;
	}
	
	public static char shapeToChar( int piece )
	{
		if ( piece == piece_I )
			return 'I';
		else if ( piece == piece_T )
			return 'T';
		else if ( piece == piece_O )
			return 'O';
		else if ( piece == piece_L )
			return 'L';
		else if ( piece == piece_J )
			return 'J';
		else if ( piece == piece_S )
			return 'S';
		else if ( piece == piece_Z )
			return 'Z';
		else if ( piece == piece_Unknown )
			return '_';
		else
			return '?';
	}
	
	public boolean collision( short[] location )
	{
		return collision( location[0], location[1], location[2], location[3] );
	}
	
	private boolean collision( int piece, int dir, int row, int col )
	{
		if ( piece == piece_T )
		{
			if ( dir == 0 ) // north T piece
			{
				if ( ( (field[row+1]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col+2)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col)&1 ) != 0 )
					return true;
			}
			else if ( dir == 1 ) // east T piece
			{
				if ( ( (field[row+1]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col)&1 ) != 0 )
					return true;
				if ( ( (field[row+1]>>col)&1 ) != 0 )
					return true;
				if ( ( (field[row+2]>>col)&1 ) != 0 )
					return true;
			}
			else if ( dir == 2 ) // south T piece
			{
				if ( ( (field[row+1]>>col+2)&1 ) != 0 )
					return true;
				if ( ( (field[row+1]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row+1]>>col)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col+1)&1 ) != 0 )
					return true;
			}
			else if ( dir == 3 ) // west T piece
			{
				if ( ( (field[row]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row+1]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row+2]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row+1]>>col)&1 ) != 0 )
					return true;
			}
		}
		else if ( piece == piece_L )
		{
			if ( dir == 0 ) // north L piece
			{
				if ( ( (field[row+1]>>col+2)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col+2)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col)&1 ) != 0 )
					return true;
			}
			else if ( dir == 1 ) // east L piece
			{
				if ( ( (field[row]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col)&1 ) != 0 )
					return true;
				if ( ( (field[row+1]>>col)&1 ) != 0 )
					return true;
				if ( ( (field[row+2]>>col)&1 ) != 0 )
					return true;
			}
			else if ( dir == 2 ) // south L piece
			{
				if ( ( (field[row+1]>>col+2)&1 ) != 0 )
					return true;
				if ( ( (field[row+1]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row+1]>>col)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col)&1 ) != 0 )
					return true;
			}
			else if ( dir == 3 ) // west L piece
			{
				if ( ( (field[row]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row+1]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row+2]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row+2]>>col)&1 ) != 0 )
					return true;
			}
		}
		else if ( piece == piece_J )
		{
			if ( dir == 0 ) // north J piece
			{
				if ( ( (field[row+1]>>col)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col+2)&1 ) != 0 )
					return true;
			}
			else if ( dir == 1 ) // east J piece
			{
				if ( ( (field[row]>>col)&1 ) != 0 )
					return true;
				if ( ( (field[row+1]>>col)&1 ) != 0 )
					return true;
				if ( ( (field[row+2]>>col)&1 ) != 0 )
					return true;
				if ( ( (field[row+2]>>col+1)&1 ) != 0 )
					return true;
			}
			else if ( dir == 2 ) // south J piece
			{
				if ( ( (field[row+1]>>col)&1 ) != 0 )
					return true;
				if ( ( (field[row+1]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row+1]>>col+2)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col+2)&1 ) != 0 )
					return true;
			}
			else if ( dir == 3 ) // west J piece
			{
				if ( ( (field[row]>>col)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row+1]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row+2]>>col+1)&1 ) != 0 )
					return true;
			}			
		}
		else if ( piece == piece_S )
		{
			if ( dir == 0 || dir == 2 ) // horizontal S piece
			{
				if ( ( (field[row+1]>>col+2)&1 ) != 0 )
					return true;
				if ( ( (field[row+1]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col)&1 ) != 0 )
					return true;
			}
			else if ( dir == 1 || dir == 3 ) // vertical S piece
			{
				if ( ( (field[row]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row+1]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row+1]>>col)&1 ) != 0 )
					return true;
				if ( ( (field[row+2]>>col)&1 ) != 0 )
					return true;
			}
		}
		else if ( piece == piece_Z )
		{
			if ( dir == 0 || dir == 2 ) // horizontal Z piece
			{
				if ( ( (field[row+1]>>col)&1 ) != 0 )
					return true;
				if ( ( (field[row+1]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col+2)&1 ) != 0 )
					return true;
			}
			else if ( dir == 1 || dir == 3 ) // vertical Z piece
			{
				if ( ( (field[row]>>col)&1 ) != 0 )
					return true;
				if ( ( (field[row+1]>>col)&1 ) != 0 )
					return true;
				if ( ( (field[row+1]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row+2]>>col+1)&1 ) != 0 )
					return true;
			}
		}
		else if ( piece == piece_I )
		{
			if ( dir == 0 || dir == 2 ) // horizontal I piece
			{
				if ( ( (field[row]>>col)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col+2)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col+3)&1 ) != 0 )
					return true;
			}
			else if ( dir == 1 || dir == 3 ) // vertical I piece
			{
				if ( ( (field[row]>>col)&1 ) != 0 )
					return true;
				if ( ( (field[row+1]>>col)&1 ) != 0 )
					return true;
				if ( ( (field[row+2]>>col)&1 ) != 0 )
					return true;
				if ( ( (field[row+3]>>col)&1 ) != 0 )
					return true;
			}
		}
		else if ( piece == piece_O )
		{
			if ( dir <= 4 ) // every O piece
			{
				if ( ( (field[row+1]>>col)&1 ) != 0 )
					return true;
				if ( ( (field[row+1]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col)&1 ) != 0 )
					return true;
			}
		}		
		return false;
	}
	
	public void insertPiece( int piece, int dir, int row, int col )
	{
		if ( piece == piece_T )
		{		
			if ( dir == 0 ) // north T piece
			{
				field[row+1] ^= 1 << col+1;
				field[row] ^= 1 << col+2;
				field[row] ^= 1 << col+1;
				field[row] ^= 1 << col;
			}
			else if ( dir == 1 ) // east T piece
			{
				field[row+1] ^= 1 << col+1;
				field[row] ^= 1 << col;
				field[row+1] ^= 1 << col;
				field[row+2] ^= 1 << col;
			}
			else if ( dir == 2 ) // south T piece
			{
				field[row+1] ^= 1 << col+2;
				field[row+1] ^= 1 << col+1;
				field[row+1] ^= 1 << col;
				field[row] ^= 1 << col+1;
			}
			else if ( dir == 3 ) // west T piece
			{
				field[row] ^= 1 << col+1;
				field[row+1] ^= 1 << col+1;
				field[row+2] ^= 1 << col+1;
				field[row+1] ^= 1 << col;
			}			
		}
		else if ( piece == piece_L )
		{		
			if ( dir == 0 ) // north L piece
			{
				field[row+1] ^= 1 << col+2;
				field[row] ^= 1 << col+2;
				field[row] ^= 1 << col+1;
				field[row] ^= 1 << col;
			}
			else if ( dir == 1 ) // east L piece
			{
				field[row] ^= 1 << col+1;
				field[row] ^= 1 << col;
				field[row+1] ^= 1 << col;
				field[row+2] ^= 1 << col;
			}
			else if ( dir == 2 ) // south L piece
			{
				field[row+1] ^= 1 << col+2;
				field[row+1] ^= 1 << col+1;
				field[row+1] ^= 1 << col;
				field[row] ^= 1 << col;
			}

			else if ( dir == 3 ) // west L piece
			{

				field[row] ^= 1 << col+1;
				field[row+1] ^= 1 << col+1;
				field[row+2] ^= 1 << col+1;
				field[row+2] ^= 1 << col;
			}			
		}
		else if ( piece == piece_J )
		{		
			if ( dir == 0 ) // north J piece
			{
				field[row+1] ^= 1 << col;
				field[row] ^= 1 << col;
				field[row] ^= 1 << col+1;
				field[row] ^= 1 << col+2;
			}
			else if ( dir == 1 ) // east J piece
			{
				field[row] ^= 1 << col;
				field[row+1] ^= 1 << col;
				field[row+2] ^= 1 << col;
				field[row+2] ^= 1 << col+1;
			}
			
			else if ( dir == 2 ) // south J piece
			{
				field[row+1] ^= 1 << col;
				field[row+1] ^= 1 << col+1;
				field[row+1] ^= 1 << col+2;
				field[row] ^= 1 << col+2;
			}
			else if ( dir == 3 ) // west J piece
			{
				field[row] ^= 1 << col;
				field[row] ^= 1 << col+1;
				field[row+1] ^= 1 << col+1;
				field[row+2] ^= 1 << col+1;
			}
		}
		else if ( piece == piece_S )
		{		
			if ( dir == 0 || dir == 2 ) // horizontal S piece
			{
				field[row+1] ^= 1 << col+2;
				field[row+1] ^= 1 << col+1;
				field[row] ^= 1 << col+1;
				field[row] ^= 1 << col;
			}
			else if ( dir == 1 || dir == 3 ) // vertical S piece
			{
				field[row] ^= 1 << col+1;
				field[row+1] ^= 1 << col+1;
				field[row+1] ^= 1 << col;
				field[row+2] ^= 1 << col;
			}
		}
		else if ( piece == piece_Z )
		{
			if ( dir == 0 || dir == 2 ) // horizontal Z piece
			{
				field[row+1] ^= 1 << col;
				field[row+1] ^= 1 << col+1;
				field[row] ^= 1 << col+1;
				field[row] ^= 1 << col+2;
			}
			else if ( dir == 1 || dir == 3 ) // vertical Z piece
			{
				field[row] ^= 1 << col;
				field[row+1] ^= 1 << col;
				field[row+1] ^= 1 << col+1;
				field[row+2] ^= 1 << col+1;
			}
		}
		else if ( piece == piece_I )
		{
			if ( dir == 0 || dir == 2 ) // horizontal I piece
			{
				field[row] ^= 1 << col;
				field[row] ^= 1 << col+1;
				field[row] ^= 1 << col+2;
				field[row] ^= 1 << col+3;
			}
			else if ( dir == 1 || dir == 3 ) // vertical I piece
			{
				field[row] ^= 1 << col;
				field[row+1] ^= 1 << col;
				field[row+2] ^= 1 << col;
				field[row+3] ^= 1 << col;
			}
		}
		else if ( piece == piece_O )
		{
			if ( dir <= 4 ) // every O piece
			{
				field[row+1] ^= 1 << col;
				field[row+1] ^= 1 << col+1;
				field[row] ^= 1 << col+1;
				field[row] ^= 1 << col;
			}
		}
	}
	
	private void clearLines()
	{
		int height = field.length;
		int clears = 0;
		for ( int y = 0; y < height; y++ )
		{
			while ( y+clears < height && field[y+clears] == fullrow )
				clears += 1;
			if ( y + clears >= height )
				field[y] = emptyrow;
			else if ( clears > 0 )
				field[y] = field[y+clears];
		}
		if ( clears > 0 )
		{
			height -= clears;
			short[] copy = new short[height];
			for ( int y = 0; y < height; y++ )
				copy[y] = field[y];
			field = copy;
		}
	}
	
	public void drop( int piece, int dir, int row, int col )
	{
		while ( row > 0 && !collision(piece, dir, row-1, col) )
			row -= 1;
		insertPiece(piece,dir,row,col);
		clearLines();
	}
	
	// matrix[row][col] whereas row = 0 means bottom, and col = 0 means left side
	public boolean[][] getMatrix()
	{
		int height = field.length;
		boolean[][] matrix = new boolean[height][width];
		for ( int row = 0; row < height; row++ )
			for ( int col = 0; col < width; col++ )
				matrix[row][col] = ( (field[row]>>col)&1 ) != 0;
		return matrix;
	}
	
	// matrix[row][col] whereas row = 0 means bottom, and col = 0 means left side
	public void setMatrix( boolean[][] matrix )
	{
		int height = field.length;
		for ( int row = 0; row < height; row++ )
			field[row] = emptyrow;
		for ( int row = 0; row < height; row++ )
			for ( int col = 0; col < width; col++ )
				if ( matrix[row][col] == true )
					field[row] |= 1 << col;
	}
	
	public String toString()
	{
		int height = field.length;
		String str = "";
		for ( int row = height-1; row >= 0; row-- )
		{
			for ( int col = 0; col < width; col++ )
			{
				if ( ( (field[row]>>col)&1 ) != 0 )
					str += "X";
				else
					str += "_";
			}
			str = str + "\n";	
		}
		str += "hold = " + shapeToChar( piece );
		str += " , paths  = " + paths;
		str += " , overhangs = " + ( overhangs + 128 );
		return str;
	}
	
	public String ancestorString()
	{
		if ( ancestor != null )
			return ancestor.ancestorString() + "\n" + this.toString();
		else
			return this.toString();
	}
	
	// location[0] = piece
	// location[1] = direction
	// location[2] = row
	// location[3] = column
	public short[] resetLocation( short nextPiece )
	{
		short[] location = new short[4];
		if ( nextPiece != piece_Unknown )
			location[0] = nextPiece;
		else
			location[0] = piece;
		location[1] = 0;
		location[2] = 0;
		location[3] = -1;
		return location;
	}
	
	public FieldArr createField( short[] location, short nextPiece )
	{
		FieldArr copy = new FieldArr( this );
		copy.insertPiece( location[0], location[1], location[2], location[3] );
		copy.clearLines();
		copy.ancestor = this;
		copy.overhangs += copy.overhangCells();
		if ( location[0] == this.piece ) // used hold
			copy.piece = (byte) nextPiece;
		return copy;
	}
	
	// increase row -> increase column -> increase direction -> use hold
	public boolean getNextLocation( short[] location )
	{
		short piece = location[0];
		short dir = location[1];
		int directions;
		if ( piece == piece_O )
			directions = 1;
		else if ( piece == piece_I || piece == piece_S || piece == piece_Z )
			directions = 2;
		else
			directions = 4;
		if ( dir == directions )
		{
			if ( piece == this.piece || this.piece == piece_Unknown )
				return false;
			location[0] = this.piece;
			location[1] = 0;
			return getNextLocation( location );
		}
//		if ( piece == piece_Unknown )
//			System.out.println( "something went wrong" ); // <--
		short row = location[2];
		short col = location[3];
		int topRow = field.length;
		int rightCol = FieldArr.width;
		if ( piece == piece_O )
		{
			rightCol -= 2;
			topRow -= 2;
		}
		else if ( piece == piece_I )
		{
			if ( dir == 0 || dir == 2 )
			{
				rightCol -= 4;
				topRow -= 1;
			}
			else
			{
				rightCol -= 1;
				topRow -= 4;				
			}
		}
		else // piece = S,Z,T,L,J
		{
			if ( dir == 0 || dir == 2 )
			{
				rightCol -= 3;
				topRow -= 2;
			}
			else
			{
				rightCol -= 2;
				topRow -= 3;
			}
		}
		if ( topRow < 0 )
		{
			location[1] += 1;
			location[2] = 0;
			location[3] = -1;
			return getNextLocation( location );
		}
		while( true )
		{
			if ( col < rightCol )
				col += 1;
			else if ( row < topRow )
			{
				row += 1;
				col = 0;
			}
			else
			{
				location[1] += 1;
				location[2] = 0;
				location[3] = -1;
				return getNextLocation( location );
			}
			if ( !collision(piece,dir,row,col) && ( row == 0 || collision(piece,dir,row-1,col) ) )
			{
				location[2] = row;
				location[3] = col;
				return true;
			}	
		}
	}
	
	public boolean locationOnSurface( short[] location )
	{
		return locationOnSurface( location[0], location[1], location[2], location[3] );
	}
	
	private boolean locationOnSurface( int piece, int dir, int row, int col )
	{
		while ( ++row < field.length )
		{
			if ( collisionOutside(piece, dir, row, col) )
				return false;
		}
		return true;
	}
	
	// ############ check overhangs and kicks ################
	
	public static final int[][][] SRSKICK_R =
	{
		{{ 0, 0},{-1, 0},{-1, 1},{ 0,-2},{-1,-2}},	// 0>>1
		{{ 0, 0},{ 1, 0},{ 1,-1},{ 0, 2},{ 1, 2}},	// 1>>2
		{{ 0, 0},{ 1, 0},{ 1, 1},{ 0,-2},{ 1,-2}},	// 2>>3
		{{ 0, 0},{-1, 0},{-1,-1},{ 0, 2},{-1, 2}},	// 3>>0
	};
	public static final int[][][] SRSKICK_L  =
	{
		{{ 0, 0},{ 1, 0},{ 1, 1},{ 0,-2},{ 1,-2}},	// 0>>3
		{{ 0, 0},{ 1, 0},{ 1,-1},{ 0, 2},{ 1, 2}},	// 1>>0
		{{ 0, 0},{-1, 0},{-1, 1},{ 0,-2},{-1,-2}},	// 2>>1
		{{ 0, 0},{-1, 0},{-1,-1},{ 0, 2},{-1, 2}},	// 3>>2
	};
	public static final int[][][] SRSKICK_RI =
	{
		{{ 0, 0},{-2, 0},{ 1, 0},{-2,-1},{ 1, 2}},	// 0>>1
		{{ 0, 0},{-1, 0},{ 2, 0},{-1, 2},{ 2,-1}},	// 1>>2
		{{ 0, 0},{ 2, 0},{-1, 0},{ 2, 1},{-1,-2}},	// 2>>3
		{{ 0, 0},{ 1, 0},{-2, 0},{ 1,-2},{-2, 1}},	// 3>>0
	};
	public static final int[][][] SRSKICK_LI =
	{
		{{ 0, 0},{-1, 0},{ 2, 0},{-1, 2},{ 2,-1}},	// 0>>3
		{{ 0, 0},{ 2, 0},{-1, 0},{ 2, 1},{-1,-2}},	// 1>>0
		{{ 0, 0},{ 1, 0},{-2, 0},{ 1,-2},{-2, 1}},	// 2>>1
		{{ 0, 0},{-2, 0},{ 1, 0},{-2,-1},{ 1, 2}},	// 3>>2
	};
	
	static short[][] kick_RX, kick_LX;
	static short[][] kick_RY, kick_LY;
	static short[][] ikick_RX, ikick_LX;
	static short[][] ikick_RY, ikick_LY;
	
	private static int adjustLocationX( int dir, boolean tPiece )
	{
		if ( tPiece )
		{
			if ( dir == 1 )
				return -1;
			else
				return 0;
		}
		else // I piece
		{
			if ( dir == 1 )
				return -2;
			else if ( dir == 3 )
				return -1;
			else
				return 0;
		}
	}
	
	private static int adjustLocationY( int dir, boolean tPiece )
	{
		if ( tPiece )
		{
			if ( dir == 0 )
				return -1;
			else
				return 0;
		}
		else // I piece
		{
			if ( dir == 0 )
				return -2;
			else if ( dir == 2 )
				return -1;
			else
				return 0;
		}
	}
	
	public static void calculateAdjustedKicks()
	{
		// T,L,J,S,Z kicks
		kick_RX = new short[4][];
		kick_RY = new short[4][];
		for ( int i = 0; i < 4; i++ )
		{
			int xi = adjustLocationX( i, true );
			int yi = adjustLocationY( i, true );
			int xj = adjustLocationX((i+1)%4, true ); // rotate right
			int yj = adjustLocationY((i+1)%4, true ); // rotate right
			kick_RX[i] = new short[SRSKICK_R[i].length];
			kick_RY[i] = new short[SRSKICK_R[i].length];
			for ( int k = 0; k < SRSKICK_R[i].length; k++ )
			{
				kick_RX[i][k] = (short) (xi - xj + SRSKICK_R[i][k][0]);
				kick_RY[i][k] = (short) (yi - yj + SRSKICK_R[i][k][1]);
			}	
		}
		kick_LX = new short[4][];
		kick_LY = new short[4][];
		for ( int i = 0; i < 4; i++ )
		{
			int xi = adjustLocationX( i, true );
			int yi = adjustLocationY( i, true );
			int xj = adjustLocationX((i+3)%4, true ); // rotate left
			int yj = adjustLocationY((i+3)%4, true ); // rotate left
			kick_LX[i] = new short[SRSKICK_L[i].length];
			kick_LY[i] = new short[SRSKICK_L[i].length];
			for ( int k = 0; k < SRSKICK_L[i].length; k++ )
			{
				kick_LX[i][k] = (short) (xi - xj + SRSKICK_L[i][k][0]);
				kick_LY[i][k] = (short) (yi - yj + SRSKICK_L[i][k][1]);
			}
		}
		// I piece kicks
		ikick_RX = new short[4][];
		ikick_RY = new short[4][];
		for ( int i = 0; i < 4; i++ )
		{
			int xi = adjustLocationX( i, false );
			int yi = adjustLocationY( i, false );
			int xj = adjustLocationX((i+1)%4, false ); // rotate right
			int yj = adjustLocationY((i+1)%4, false ); // rotate right
			ikick_RX[i] = new short[SRSKICK_RI[i].length];
			ikick_RY[i] = new short[SRSKICK_RI[i].length];
			for ( int k = 0; k < SRSKICK_RI[i].length; k++ )
			{
				ikick_RX[i][k] = (short) (xi - xj + SRSKICK_RI[i][k][0]);
				ikick_RY[i][k] = (short) (yi - yj + SRSKICK_RI[i][k][1]);
			}	
		}
		ikick_LX = new short[4][];
		ikick_LY = new short[4][];
		for ( int i = 0; i < 4; i++ )
		{
			int xi = adjustLocationX( i, false );
			int yi = adjustLocationY( i, false );
			int xj = adjustLocationX((i+3)%4, false ); // rotate left
			int yj = adjustLocationY((i+3)%4, false ); // rotate left
			ikick_LX[i] = new short[SRSKICK_LI[i].length];
			ikick_LY[i] = new short[SRSKICK_LI[i].length];
			for ( int k = 0; k < SRSKICK_LI[i].length; k++ )
			{
				ikick_LX[i][k] = (short) (xi - xj + SRSKICK_LI[i][k][0]);
				ikick_LY[i][k] = (short) (yi - yj + SRSKICK_LI[i][k][1]);
			}	
		}
	}
	
	public boolean collisionOutside( short[] location )
	{
		return collisionOutside( location[0], location[1], location[2], location[3] );
	}
	
	private boolean collisionOutside(int piece, int dir, int row, int col)
	{
		if ( col < 0 || row < 0 )
			return true;
		int rightCol = width;
		if ( piece == piece_O )
			rightCol -= 2;
		else if ( piece == piece_I )
			if ( dir == 0 || dir == 2 )
				rightCol -= 4;
			else
				rightCol -= 1;
		else // piece = S,Z,T,L,J
			if ( dir == 0 || dir == 2 )
				rightCol -= 3;
			else
				rightCol -= 2;
		if ( col > rightCol )
			return true;
		int height = field.length;
		if ( row >= height )
			return false; // <--
		if ( piece == piece_T )
		{
			if ( dir == 0 ) // north T piece
			{
				if ( row+1 < height && ( (field[row+1]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col+2)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col)&1 ) != 0 )
					return true;
			}
			else if ( dir == 1 ) // east T piece
			{
				if ( row+1 < height && ( (field[row+1]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col)&1 ) != 0 )
					return true;
				if ( row+1 < height && ( (field[row+1]>>col)&1 ) != 0 )
					return true;
				if ( row+2 < height && ( (field[row+2]>>col)&1 ) != 0 )
					return true;
			}
			else if ( dir == 2 ) // south T piece
			{
				if ( row+1 < height && ( (field[row+1]>>col+2)&1 ) != 0 )
					return true;
				if ( row+1 < height && ( (field[row+1]>>col+1)&1 ) != 0 )
					return true;
				if ( row+1 < height && ( (field[row+1]>>col)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col+1)&1 ) != 0 )
					return true;
			}
			else if ( dir == 3 ) // west T piece
			{
				if ( ( (field[row]>>col+1)&1 ) != 0 )
					return true;
				if ( row+1 < height && ( (field[row+1]>>col+1)&1 ) != 0 )
					return true;
				if ( row+2 < height && ( (field[row+2]>>col+1)&1 ) != 0 )
					return true;
				if ( row+1 < height && ( (field[row+1]>>col)&1 ) != 0 )
					return true;
			}
		}
		else if ( piece == piece_L )
		{
			if ( dir == 0 ) // north L piece
			{
				if ( row+1 < height && ( (field[row+1]>>col+2)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col+2)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col)&1 ) != 0 )
					return true;
			}
			else if ( dir == 1 ) // east L piece
			{
				if ( ( (field[row]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col)&1 ) != 0 )
					return true;
				if ( row+1 < height && ( (field[row+1]>>col)&1 ) != 0 )
					return true;
				if ( row+2 < height && ( (field[row+2]>>col)&1 ) != 0 )
					return true;
			}
			else if ( dir == 2 ) // south L piece
			{
				if ( row+1 < height && ( (field[row+1]>>col+2)&1 ) != 0 )
					return true;
				if ( row+1 < height && ( (field[row+1]>>col+1)&1 ) != 0 )
					return true;
				if ( row+1 < height && ( (field[row+1]>>col)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col)&1 ) != 0 )
					return true;
			}
			else if ( dir == 3 ) // west L piece
			{
				if ( ( (field[row]>>col+1)&1 ) != 0 )
					return true;
				if ( row+1 < height && ( (field[row+1]>>col+1)&1 ) != 0 )
					return true;
				if ( row+2 < height && ( (field[row+2]>>col+1)&1 ) != 0 )
					return true;
				if ( row+2 < height && ( (field[row+2]>>col)&1 ) != 0 )
					return true;
			}
		}
		else if ( piece == piece_J )
		{
			if ( dir == 0 ) // north J piece
			{
				if ( row+1 < height && ( (field[row+1]>>col)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col+2)&1 ) != 0 )
					return true;
			}
			else if ( dir == 1 ) // east J piece
			{
				if ( ( (field[row]>>col)&1 ) != 0 )
					return true;
				if ( row+1 < height && ( (field[row+1]>>col)&1 ) != 0 )
					return true;
				if ( row+2 < height && ( (field[row+2]>>col)&1 ) != 0 )
					return true;
				if ( row+2 < height && ( (field[row+2]>>col+1)&1 ) != 0 )
					return true;
			}
			else if ( dir == 2 ) // south J piece
			{
				if ( row+1 < height && ( (field[row+1]>>col)&1 ) != 0 )
					return true;
				if ( row+1 < height && ( (field[row+1]>>col+1)&1 ) != 0 )
					return true;
				if ( row+1 < height && ( (field[row+1]>>col+2)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col+2)&1 ) != 0 )
					return true;
			}
			else if ( dir == 3 ) // west J piece
			{
				if ( ( (field[row]>>col)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col+1)&1 ) != 0 )
					return true;
				if ( row+1 < height && ( (field[row+1]>>col+1)&1 ) != 0 )
					return true;
				if ( row+2 < height && ( (field[row+2]>>col+1)&1 ) != 0 )
					return true;
			}			
		}
		else if ( piece == piece_S )
		{
			if ( dir == 0 || dir == 2 ) // horizontal S piece
			{
				if ( row+1 < height && ( (field[row+1]>>col+2)&1 ) != 0 )
					return true;
				if ( row+1 < height && ( (field[row+1]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col)&1 ) != 0 )
					return true;
			}
			else if ( dir == 1 || dir == 3 ) // vertical S piece
			{
				if ( ( (field[row]>>col+1)&1 ) != 0 )
					return true;
				if ( row+1 < height && ( (field[row+1]>>col+1)&1 ) != 0 )
					return true;
				if ( row+1 < height && ( (field[row+1]>>col)&1 ) != 0 )
					return true;
				if ( row+2 < height && ( (field[row+2]>>col)&1 ) != 0 )
					return true;
			}
		}
		else if ( piece == piece_Z )
		{
			if ( dir == 0 || dir == 2 ) // horizontal Z piece
			{
				if ( row+1 < height && ( (field[row+1]>>col)&1 ) != 0 )
					return true;
				if ( row+1 < height && ( (field[row+1]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col+2)&1 ) != 0 )
					return true;
			}
			else if ( dir == 1 || dir == 3 ) // vertical Z piece
			{
				if ( ( (field[row]>>col)&1 ) != 0 )
					return true;
				if ( row+1 < height && ( (field[row+1]>>col)&1 ) != 0 )
					return true;
				if ( row+1 < height && ( (field[row+1]>>col+1)&1 ) != 0 )
					return true;
				if ( row+2 < height && ( (field[row+2]>>col+1)&1 ) != 0 )
					return true;
			}
		}
		else if ( piece == piece_I )
		{
			if ( dir == 0 || dir == 2 ) // horizontal I piece
			{
				if ( ( (field[row]>>col)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col+2)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col+3)&1 ) != 0 )
					return true;
			}
			else if ( dir == 1 || dir == 3 ) // vertical I piece
			{
				if ( ( (field[row]>>col)&1 ) != 0 )
					return true;
				if ( row+1 < height && ( (field[row+1]>>col)&1 ) != 0 )
					return true;
				if ( row+2 < height && ( (field[row+2]>>col)&1 ) != 0 )
					return true;
				if ( row+3 < height && ( (field[row+3]>>col)&1 ) != 0 )
					return true;
			}
		}
		else if ( piece == piece_O )
		{
			if ( dir <= 4 ) // every O piece
			{
				if ( row+1 < height && ( (field[row+1]>>col)&1 ) != 0 )
					return true;
				if ( row+1 < height && ( (field[row+1]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col+1)&1 ) != 0 )
					return true;
				if ( ( (field[row]>>col)&1 ) != 0 )
					return true;
			}
		}		
		return false;
	}
	
	public boolean locationIsReachable( short[] location )
	{
		if ( locationOnSurface(location) )
			return true;
		int piece = location[0];
		if ( piece == piece_S || piece == piece_Z || piece == piece_I )
		{
			boolean reachable = reverseReachable( location[0], location[1], location[2], location[3], location, 0 );
			if ( !reachable )
			{
				location[1] = (short) (( location[1] + 2 ) % 4);  // rotate by 180 degrees
				reachable = reverseReachable( location[0], location[1], location[2], location[3], location, 0 );
				location[1] = (short) (( location[1] + 2 ) % 4);
			}
			return reachable;
		}
		else
			return reverseReachable( location[0], location[1], location[2], location[3], location, 0 );	
	}
	
	private boolean reverseReachable( int piece, int dir, int row, int col, short[] origin, int iteration )
	{
		if ( dir == origin[1] && row == origin[2] && col == origin[3] && iteration != 0 )
			return false;
		// System.out.println( "dir = " + dir + " , row = " + row + " , col = " + col );
		if ( locationOnSurface( piece, dir, row, col ) )
			return true;
		if ( iteration >= reverseSteps )
			return false;
		if ( !collisionOutside(piece, dir, row, col-1) ) // move left
			if ( reverseReachable(piece, dir, row, col-1, origin, iteration+1) )
				return true;
		if ( !collisionOutside(piece, dir, row, col+1) ) // move right
			if ( reverseReachable(piece, dir, row, col+1, origin, iteration+1) )
				return true;
		if ( !collisionOutside(piece, dir, row+1, col) ) // move up
			if ( reverseReachable(piece, dir, row+1, col, origin, iteration+1) )
				return true;
		if ( piece == piece_O )
			return false;
		short[][] kick_RX, kick_RY, kick_LX, kick_LY;
		if ( piece == piece_I )
		{
			kick_RX = FieldArr.ikick_RX;
			kick_RY = FieldArr.ikick_RY;
			kick_LX = FieldArr.ikick_LX;
			kick_LY = FieldArr.ikick_LY;
		}
		else
		{
			kick_RX = FieldArr.kick_RX;
			kick_RY = FieldArr.kick_RY;
			kick_LX = FieldArr.kick_LX;
			kick_LY = FieldArr.kick_LY;
		}
		int newDir, newRow, newCol;
		newDir = ( dir+1 ) % 4; // rotate right
		for ( int i = 0; i < kick_LX[newDir].length; i++ )
		{
			if ( i == 1 && !useKicks )
				break;
			newCol = col - kick_LX[newDir][i];
			newRow = row - kick_LY[newDir][i];
			// System.out.println( "cw kick " + i + " : dir = " + newDir + " , row = " + newRow + " , col = " + newCol );
			if ( collisionOutside(piece, newDir, newRow, newCol) )
				continue;
			// test if backwards kick leads to this location
			int backRow = -9;
			int backCol = -9;
			for ( int j = 0; j < kick_RX[newDir].length; j++ )
			{
				backCol = newCol + kick_LX[newDir][j];
				backRow = newRow + kick_LY[newDir][j];
				if ( !collisionOutside(piece, dir, backRow, backCol) )
					break;
			}
			// System.out.println( "back kick " + i + " : dir = " + dir + " , row = " + backRow + " , col = " + backCol );
			if ( backRow == row && backCol == col )
			{
				// System.out.println( "accepted kick " + i + " : dir = " + newDir + " , row = " + newRow + " , col = " + newCol );
				if ( reverseReachable(piece, newDir, newRow, newCol, origin, iteration+1) )
					return true;
			}
		}
		newDir = ( dir+3 ) % 4; // rotate left
		for ( int i = 0; i < kick_RX[newDir].length; i++ )
		{
			if ( i == 1 && !useKicks )
				break;
			newCol = col - kick_RX[newDir][i];
			newRow = row - kick_RY[newDir][i];
			// System.out.println( "ccw kick " + i + " : dir = " + newDir + " , row = " + newRow + " , col = " + newCol );
			if ( collisionOutside(piece, newDir, newRow, newCol) )
				continue;
			// test if backwards kick leads to this location
			int backRow = -9;
			int backCol = -9;
			for ( int j = 0; j < kick_RX[newDir].length; j++ )
			{
				backCol = newCol + kick_RX[newDir][j];
				backRow = newRow + kick_RY[newDir][j];
				if ( !collisionOutside(piece, dir, backRow, backCol) )
					break;
			}
			// System.out.println( "back kick " + i + " : dir = " + dir + " , row = " + backRow + " , col = " + backCol );
			if ( backRow == row && backCol == col )
			{
				// System.out.println( "accepted kick " + i + " : dir = " + newDir + " , row = " + newRow + " , col = " + newCol );
				if ( reverseReachable(piece, newDir, newRow, newCol, origin, iteration+1) )
					return true;
			}
		}
		return false;
	}
	
	public boolean hasOddSplit()
	{
		int height = field.length;
		for ( int col = 0; col < width-1; col++ )
		{
			boolean split = true;
			for ( int row = 0; row < height; row++ )
			{
				if ( ((field[row]>>col)&1) == 0 && ((field[row]>>col+1)&1) == 0 )
				{
					split = false;
					break;
				}
			}
			if ( split )
			{ // count empty cells in left part
				int empty = 0;
				for ( int row2 = 0; row2 < height; row2++ )
					for ( int col2 = 0; col2 <= col; col2++ )
						if ( ((field[row2]>>col2)&1) == 0 )
							empty += 1;
				if ( empty % 4 != 0 )
					return true;
			}
		}
		return false;
	}
	
	// reverse engineer
	public short[] reverseMove( short nextPiece )
	{
		FieldArr father = new FieldArr( ancestor );
		if ( this.piece == nextPiece )
			nextPiece = father.piece;
		else
			father.piece = (byte) nextPiece;
			
		short[] location = father.resetLocation( nextPiece );
		while ( true )
		{
			FieldArr test = father.createField( location, nextPiece );
			if ( test.sameMatrix(this) && PerfectClearArr.acceptMove(father, location) )
				return location;
			if ( !father.getNextLocation(location) )
				return null;
		}
	}
	
	public short overhangCells()
	{
		short overhangs = 0;
		int height = field.length;
		for ( int col = 0; col < width; col++ )
		{
			boolean filledAbove = false;
			for ( int row = height-1; row >= 0; row-- )
			{
				if ( ( (field[row]>>col)&1 ) != 0 ) // cell filled
					filledAbove = true;
				else if ( filledAbove )
					overhangs += 1;
			}
		}
		return overhangs;
	}
}
