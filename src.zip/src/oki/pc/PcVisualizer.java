package oki.pc;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.net.URL;
import java.util.Vector;

import javax.imageio.ImageIO;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;


public class PcVisualizer extends JPanel implements ActionListener, MouseListener
{
	private static final long serialVersionUID = 4009414301634969678L;
	private static final int WINDOW_WIDTH = 736;
	private static final int WINDOW_HEIGHT = 634;
	
	private static final int[] FIELD_X = {208,384,560,384,560,384,560, 32};
	private static final int[] FIELD_Y = {432,432,432,224,224, 16, 16, 32};
	private static final int[] BLOCK_SIZE = {16,16,16,16,16,16,16,32};
//	private static final int[] BOX_X = { 32, 32, 32, 32, 32, 32, 32};
//	private static final int[] BOX_Y = {420,452,484,516,548,580,612};
	
	private static final int[] nodes = { 1*1000*1000, 2*1000*1000, 4*1000*1000, 8*1000*1000, 99*1000*1000 };
	private static final int FRAME_HEIGHT = 10; // maximum number of rows
	private static final int MATRIX_WIDTH = 10;
	private static final int MATRIX_HEIGHT = 8; // maximum number of rows
	private static final int NUM_FIELDS = 7;
	private static final int NUM_TURNS = 15;
	private static final int NUM_SOLUTIONS = 100;
	private static final int GRAPHICS_DELTA1 = 8; // distance between field and its buttons
	private static final int GRAPHICS_DELTA2 = -4; // buttons height reduction
	private static final int GRAPHICS_DELTA3 = +4; // label height increasement
	private static final int GRAPHICS_DELTA4 = 4; // distance between color buttons
	private static final int GRAPHICS_DELTA5 = 12; // distance between original field and color buttons
	private static final int GRAPHICS_DELTA6 = 8; // size of the frame for the original field
	private static final int GRAPHICS_DELTA7 = 31; // added to vertical coordinates after each button, textfield, label
	private static final int GRAPHICS_DELTA8 = 160; // width of the comboboxes
	private static final int GRAPHICS_DELTA9 = 35; // added to vertical coordinates after each combobox
	private static final int GRAPHICS_DELTA10 = 90; // move labelMessage to the right
	
	private static final String IMAGE_LOCATION = "/oki/img/";
	
	public static final int FIELD_T = 0,
							FIELD_I = 1,
							FIELD_O = 2,
							FIELD_J = 3,
							FIELD_L = 4,
							FIELD_S = 5,
							FIELD_Z = 6,
							FIELD_ORIG = 7;
	
	public static final int COLOR_T =  7,
							COLOR_I = 5,
							COLOR_O = 3,
							COLOR_J = 6,
							COLOR_L = 2,
							COLOR_S = 4,
							COLOR_Z = 1,
							COLOR_FILLED = 8,
							COLOR_EMPTY = 0,
							COLOR_INVALID = 10,
							COLOR_ACTIVE = 20;
	
	private static final int NUM_COLORS = 8;
	private static final int[] BUTTON_COLOR = {8,1,2,3,4,5,6,7};
	
	// input data
	int[][] matrix;
	int[] pieceSequence;
	
	// output data
	int[][][][][] matrices; // fields[id][solution][turn][y][x]
	short[][][][] locations; // locations[id][solution][turn][piece,dir,row,col]
	int[][][] holds; // holds[id][solution][turn]
	int[][] overhangs; // overhangs[id][solution]
	int[] turns; // turn[id] , currently displayed matrices
	int[] lastTurns; // lastTurns[id] , number of turns
	int[] solutions; // solutions[id] , currently displayed matrices
	int[] lastSolutions; // lastSolution[id] , number of solutions
	int[] pieces; // pieces[turn], piece sequence
	
	
	// settings
	int settingHeight;
	int settingNodes;
	int settingSoft;
	boolean settingHold;
	boolean settingGray;
	int settingColor = COLOR_FILLED;
	
	// graphics variables
	private BufferedImage frameNW, frameN, frameW;
	private BufferedImage skin;
	private int skinSize;
	private int blockSize;
	private Graphics graphics;
	private int x0;
	private int y0;
	
	// buttons, comboboxes, etc.
	private JComboBox<String> boxHeight;
	private JComboBox<String> boxNodes;
	private JComboBox<String> boxSoft;
	private JComboBox<String> boxHold;
	private JComboBox<String> boxGray;
	private JButton buttonStart;
	private JTextField textSequence;
	private JLabel labelMessage;
	private JButton[] buttonsPrev;
	private JButton[] buttonsNext;
	private JButton[] buttonsSolution;
	private JLabel[] labelsTurn;
	private JRadioButton[] buttonsColor;
	private JButton buttonTest;
	private JLabel labelTest;
	
	public PcVisualizer()
	{
		super();
		skin = loadImage( IMAGE_LOCATION + "skin.png" );
		frameN = loadImage( IMAGE_LOCATION + "framen.png" );
		frameW = loadImage( IMAGE_LOCATION + "framew.png" );
		frameNW = loadImage( IMAGE_LOCATION + "framenw.png" );
		skinSize = skin.getHeight();
		setBackground( new Color(158,164,175) );
		// place this panel on a frame
		JFrame frame = new JFrame("Perfect Clear Finder");
		frame.add(this);
		// show buttons on screen
		setLayout(null);
		initButtons();
		initInput();
		initVariables();
		// show window
		frame.setResizable(false);
		setPreferredSize( new Dimension(WINDOW_WIDTH,WINDOW_HEIGHT) );
	    frame.pack();
	    frame.setLocationRelativeTo(null);
	    repaint();
		frame.setVisible(true);
		addMouseListener(this);
		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent windowEvent)
			{
				System.exit(0);
			}
		});
	}
	
	public BufferedImage loadImage(String filename)
	{
		try 
		{
			URL url = getClass().getResource(filename);
			System.out.println("try to load: " + url.toString() );
			return ImageIO.read( url );
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return null;
	}
	
	private void initInput()
	{
		int width = MATRIX_WIDTH;
		int height = MATRIX_HEIGHT;
		
		matrix = new int[height][width];
//		int I = COLOR_I;
//		int T = COLOR_T;
//		int O = COLOR_O;
//		int L = COLOR_L;
//		int J = COLOR_J;
//		int S = COLOR_S;
//		int Z = COLOR_Z;
//		int _ = COLOR_EMPTY;
//		int X = COLOR_FILLED;
//		matrix = new int[][]
//		{
//			{I,I,I,I,_,X,X,Z,Z,T},
//			{L,L,J,J,_,_,Z,Z,T,T},
//			{L,O,O,J,_,X,X,S,S,T},
//			{L,O,O,J,_,_,_,_,S,S},
//			{_,_,_,_,_,_,_,_,_,_},
//			{_,_,_,_,_,_,_,_,_,_},
//			{_,_,_,_,_,_,_,_,_,_},
//			{_,_,_,_,_,_,_,_,_,_},
//		};
//		matrix = new int[][]
//		{
//			{I,X,X,_,_,_,_,X,X,X},
//			{L,X,X,_,_,_,_,X,X,T},
//			{J,X,X,_,_,_,_,X,X,Z},
//			{O,X,X,_,_,_,_,X,X,S},
//			{_,_,_,_,_,_,_,_,_,_},
//			{_,_,_,_,_,_,_,_,_,_},
//			{_,_,_,_,_,_,_,_,_,_},
//			{_,_,_,_,_,_,_,_,_,_},
//		};
	}
	
	private void initVariables()
	{
		matrices = new int[NUM_FIELDS][1][NUM_TURNS][MATRIX_HEIGHT][MATRIX_WIDTH];
		locations = new short[NUM_FIELDS][1][NUM_TURNS][4];
		holds = new int[NUM_FIELDS][1][NUM_TURNS];
		overhangs = new int[NUM_FIELDS][1];
		turns = new int[NUM_FIELDS];
		lastTurns = new int[NUM_FIELDS];
		solutions = new int[NUM_FIELDS];
		lastSolutions = new int[NUM_FIELDS];
		pieces = new int[NUM_TURNS+1];
		for ( int i = 0; i < NUM_FIELDS; i++ )
			lastSolutions[i] = -1;
	}
	
	private void initButtons()
	{
		Dimension size;
		String[] strings;
		int x, y, h;
		
		x = FIELD_X[FIELD_ORIG] - GRAPHICS_DELTA6;
		y = FIELD_Y[FIELD_ORIG] + FRAME_HEIGHT*BLOCK_SIZE[FIELD_ORIG] + GRAPHICS_DELTA5;
		
		textSequence = new JTextField(12);
		textSequence.addActionListener(this);
		// textSequence.setText( "JLTSZIOSZIO" );
		// textSequence.setText( "JLOOII" );
		// textSequence.setText( "JOLI" );
		textSequence.setText( "SIISZTLJOS" );
		size = textSequence.getPreferredSize();
		// textSequence.setBounds( BOX_X[5] + insets.left, BOX_Y[5] + insets.top, size.width, size.height );
		textSequence.setBounds( x, y, size.width, size.height );
		this.add( textSequence );
		
		buttonStart = new JButton(" Start ");
		buttonStart.addActionListener(this);
		buttonStart.setFocusPainted(false);
		size = buttonStart.getPreferredSize();
		// buttonStart.setBounds( BOX_X[4] + insets.left, BOX_Y[4] + insets.top, size.width, size.height );
		y += GRAPHICS_DELTA7;
		buttonStart.setBounds( x, y, size.width, size.height );
		this.add( buttonStart );
		
		labelMessage = new JLabel("perfect clear finder");
		h = (int) labelMessage.getPreferredSize().getHeight();
		labelMessage.setPreferredSize( new Dimension(330-GRAPHICS_DELTA10,h) );
		size = labelMessage.getPreferredSize();
		// labelMessage.setBounds( BOX_X[6] + insets.left, BOX_Y[6] + insets.top, size.width, size.height );
		x += GRAPHICS_DELTA10;
		y += 2;
		labelMessage.setBounds( x, y, size.width, size.height );
		x -= GRAPHICS_DELTA10;
		y -= 1;
		this.add( labelMessage );
		
		strings = new String[]{ "perf. clear after 2 rows", "perf. clear after 3 rows", "perf. clear after 4 rows","perf. clear after 5 rows", 
								"perf. clear after 6 rows", "perf. clear after 7 rows", "perf. clear after 8 rows" };
		boxHeight = new JComboBox<>( strings );
		boxHeight.setSelectedIndex( 2 );
		// boxHeight.setSelectedIndex( 0 );
		boxHeight.addActionListener(this);
		h = (int) boxHeight.getPreferredSize().getHeight();
		boxHeight.setPreferredSize( new Dimension(GRAPHICS_DELTA8,h) );
		size = boxHeight.getPreferredSize();
		// boxHeight.setBounds( BOX_X[0] + insets.left, BOX_Y[0] + insets.top, size.width, size.height );
		y += GRAPHICS_DELTA9;
		boxHeight.setBounds( x, y, size.width, size.height );
		this.add( boxHeight );
		settingHeight = boxHeight.getSelectedIndex() + 2;
		
		strings = new String[]{ "< " + nodes[0] + " fields per ply", "< " + nodes[1] + " fields per ply", "< " + nodes[2] + " fields per ply", "< " + nodes[3] + " fields per ply", "unlimited # of fields" };
		boxNodes = new JComboBox<>( strings );
		boxNodes.setSelectedIndex( 4 );
		boxNodes.addActionListener(this);
		h = (int) boxNodes.getPreferredSize().getHeight();
		boxNodes.setPreferredSize( new Dimension(GRAPHICS_DELTA8,h) );
		size = boxNodes.getPreferredSize();
		// boxNodes.setBounds( BOX_X[1] + insets.left, BOX_Y[1] + insets.top, size.width, size.height );
		y += GRAPHICS_DELTA9;
		boxNodes.setBounds( x, y, size.width, size.height );
		this.add( boxNodes );
		settingNodes = nodes[ boxNodes.getSelectedIndex() ];
		
		strings = new String[]{ "use harddrop only", "softdop but no kicks", "use softdrop & kicks", "use deepdrop" };
		boxSoft = new JComboBox<>( strings );
		boxSoft.setSelectedIndex( 2 );
		boxSoft.addActionListener(this);
		h = (int) boxSoft.getPreferredSize().getHeight();
		boxSoft.setPreferredSize( new Dimension(GRAPHICS_DELTA8,h) );
		size = boxSoft.getPreferredSize();
		// boxSoft.setBounds( BOX_X[2] + insets.left, BOX_Y[2] + insets.top, size.width, size.height );
		y += GRAPHICS_DELTA9;
		boxSoft.setBounds( x, y, size.width, size.height );
		this.add( boxSoft );
		settingSoft = boxSoft.getSelectedIndex();
		
		strings = new String[]{ "avoid hold feature", "use hold feature" };
		boxHold = new JComboBox<>( strings );
		boxHold.setSelectedIndex( 1 );
		boxHold.addActionListener(this);
		h = (int) boxHold.getPreferredSize().getHeight();
		boxHold.setPreferredSize( new Dimension(GRAPHICS_DELTA8,h) );
		size = boxHold.getPreferredSize();
		// boxHold.setBounds( BOX_X[3] + insets.left, BOX_Y[3] + insets.top, size.width, size.height );
		y += GRAPHICS_DELTA9;
		boxHold.setBounds( x, y, size.width, size.height );
		this.add( boxHold );
		settingHold = ( boxHold.getSelectedIndex() == 1 );
		
		strings = new String[]{ "colored output matrices" , "grey output matrices" };
		boxGray = new JComboBox<>( strings );
		boxGray.setSelectedIndex( 1 );
		boxGray.addActionListener(this);
		h = (int) boxGray.getPreferredSize().getHeight();
		boxGray.setPreferredSize( new Dimension(GRAPHICS_DELTA8,h) );
		size = boxGray.getPreferredSize();
		// boxHold.setBounds( BOX_X[3] + insets.left, BOX_Y[3] + insets.top, size.width, size.height );
		y += GRAPHICS_DELTA9;
		boxGray.setBounds( x, y, size.width, size.height );
		this.add( boxGray );
		settingGray = ( boxGray.getSelectedIndex() == 1 );
		
		// JLabel[] labelsTurn, JButton[] buttonsPrev, JButton[] buttonsNext, JRadioButton[] buttonsColor
		int w1, w2, w3;
		buttonTest = new JButton("abcdefghijklmnopqrstuvwxyz");
		Insets insets = buttonTest.getMargin();
		insets.left = 5;
		insets.right = 4;
		Insets insets2 = new Insets(insets.top,1,insets.bottom,0);
		
		buttonTest.setMargin( insets );
		buttonTest.setText(" < ");
		w1 = buttonTest.getPreferredSize().width;
		labelTest = new JLabel( turnText(10,10) );
		w2 = labelTest.getPreferredSize().width;
		buttonTest.setMargin( insets2 );
		buttonTest.setText( solutionsText(10,10) );
		w3 = buttonTest.getPreferredSize().width;
		
		buttonsPrev = new JButton[NUM_FIELDS];
		for ( int i = 0; i < NUM_FIELDS; i++ )
		{
			buttonsPrev[i] = new JButton(" < ");
			buttonsPrev[i].addActionListener(this);
			buttonsPrev[i].setFocusPainted(false);
			buttonsPrev[i].setMargin( insets );
			size = buttonsPrev[i].getPreferredSize();
			x = FIELD_X[i] + BLOCK_SIZE[i]*MATRIX_WIDTH/2 - w1 + ( -w2 - w3 )/2 - 4;
			y = FIELD_Y[i] + FRAME_HEIGHT*BLOCK_SIZE[i] + GRAPHICS_DELTA1;
			buttonsPrev[i].setBounds( x , y , size.width, size.height + GRAPHICS_DELTA2 );
			this.add( buttonsPrev[i] );
		}
		
		labelsTurn = new JLabel[NUM_FIELDS];
		for ( int i = 0; i < NUM_FIELDS; i++ )
		{
			labelsTurn[i] = new JLabel( turnText(0,0) );
			labelsTurn[i].setHorizontalAlignment( SwingConstants.CENTER );
			size = labelsTurn[i].getPreferredSize();
			size.width = w2;
			labelsTurn[i].setPreferredSize( size );
			x = FIELD_X[i] + BLOCK_SIZE[i]*MATRIX_WIDTH/2 + ( -w2 - w3 )/2 - 4;
			y = FIELD_Y[i] + FRAME_HEIGHT*BLOCK_SIZE[i] + GRAPHICS_DELTA1;
			labelsTurn[i].setBounds( x , y , size.width, size.height + GRAPHICS_DELTA3 );
			this.add( labelsTurn[i] );
		}
		
		buttonsNext = new JButton[NUM_FIELDS];
		for ( int i = 0; i < NUM_FIELDS; i++ )
		{
			buttonsNext[i] = new JButton(" > ");
			buttonsNext[i].addActionListener(this);
			buttonsNext[i].setFocusPainted(false);
			buttonsNext[i].setMargin( insets );
			size = buttonsNext[i].getPreferredSize();
			x = FIELD_X[i] + BLOCK_SIZE[i]*MATRIX_WIDTH/2 + ( w2 - w3 )/2 - 4;
			y = FIELD_Y[i] + FRAME_HEIGHT*BLOCK_SIZE[i] + GRAPHICS_DELTA1;
			buttonsNext[i].setBounds( x , y , size.width, size.height + GRAPHICS_DELTA2 );
			this.add( buttonsNext[i] );
		}
		
		buttonsSolution = new JButton[NUM_FIELDS];
		for ( int i = 0; i < NUM_FIELDS; i++ )
		{
			buttonsSolution[i] = new JButton( solutionsText(0,0) );
			buttonsSolution[i].setHorizontalAlignment( SwingConstants.CENTER );
			buttonsSolution[i].addActionListener(this);
			buttonsSolution[i].setFocusPainted(false);
			buttonsSolution[i].setMargin( insets2 );
			size = buttonsSolution[i].getPreferredSize();
			size.width = w3;
			x = FIELD_X[i] + BLOCK_SIZE[i]*MATRIX_WIDTH/2 + w1 + ( w2 - w3 )/2 + 4;
			y = FIELD_Y[i] + FRAME_HEIGHT*BLOCK_SIZE[i] + GRAPHICS_DELTA1;
			buttonsSolution[i].setBounds( x , y , size.width, size.height + GRAPHICS_DELTA2 );
			this.add( buttonsSolution[i] );
		}
		
		ButtonGroup colorGroup = new ButtonGroup();
		buttonsColor = new JRadioButton[NUM_COLORS];
		for ( int i = 0; i < NUM_COLORS; i++ )
		{
			buttonsColor[i] = new JRadioButton();
			colorGroup.add( buttonsColor[i] );
			if ( BUTTON_COLOR[i] == COLOR_FILLED )
				buttonsColor[i].setBackground( Color.lightGray );
			else if ( BUTTON_COLOR[i] == COLOR_Z )
				buttonsColor[i].setBackground( Color.red );
			else if ( BUTTON_COLOR[i] == COLOR_L )
				buttonsColor[i].setBackground( Color.orange );
			else if ( BUTTON_COLOR[i] == COLOR_O )
				buttonsColor[i].setBackground( Color.yellow );
			else if ( BUTTON_COLOR[i] == COLOR_S )
				buttonsColor[i].setBackground( Color.green );
			else if ( BUTTON_COLOR[i] == COLOR_I )
				buttonsColor[i].setBackground( Color.cyan );
			else if ( BUTTON_COLOR[i] == COLOR_J )
				buttonsColor[i].setBackground( Color.blue );
			else if ( BUTTON_COLOR[i] == COLOR_T )
				buttonsColor[i].setBackground( Color.magenta );
			
			size = buttonsColor[i].getPreferredSize();
			x = FIELD_X[FIELD_ORIG] + BLOCK_SIZE[FIELD_ORIG]*MATRIX_WIDTH - ( NUM_COLORS - i )*size.width - (NUM_COLORS-1-i)*GRAPHICS_DELTA4 + GRAPHICS_DELTA6;
			y = FIELD_Y[FIELD_ORIG] + FRAME_HEIGHT*BLOCK_SIZE[FIELD_ORIG] + GRAPHICS_DELTA5;
			buttonsColor[i].setBounds( x , y , size.width, size.height );
			buttonsColor[i].addActionListener(this);
			this.add( buttonsColor[i] );
		}
		buttonsColor[0].setSelected(true);
		settingColor = BUTTON_COLOR[0];
	}

	public void actionPerformed(ActionEvent event) 
	{
		Object item = event.getSource();
		if ( item == boxHeight )
		{
			int index = boxHeight.getSelectedIndex();
			settingHeight = index + 2;
			repaint();
		}
		else if ( item == boxNodes )
		{
			int index = boxNodes.getSelectedIndex();
			settingNodes = nodes[index];
		}
		else if ( item == boxSoft )
		{
			int index = boxSoft.getSelectedIndex();
			settingSoft = index;
		}
		else if ( item == boxHold )
		{
			int index = boxHold.getSelectedIndex();
			settingHold = ( index == 1 );
		}
		else if ( item == boxGray )
		{
			int index = boxGray.getSelectedIndex();
			settingGray = ( index == 1 );
			repaint();
		}
		else if ( item == buttonStart )
		{
			executeCalculation();
		}
		else if ( item == textSequence )
		{
			 pieceSequence = readPieceSequence();
			 if ( pieceSequence == null)
				 writeMessage( "only letters I,T,O,L,J,S,Z are valid" );
			 else
				 writeMessage( "Sequence updated: " + textSequence.getText().toUpperCase() );
		}
		else
		{
			for ( int i = 0; i < NUM_FIELDS; i++ )
			{
				if ( item == buttonsPrev[i] )
					decreaseTurn(i);
			}
			for ( int i = 0; i < NUM_FIELDS; i++ )
			{
				if ( item == buttonsNext[i] )
					increaseTurn(i);
			}
			for ( int i = 0; i < NUM_FIELDS; i++ )
			{
				if ( item == buttonsSolution[i] )
					cycleSolution(i);
			}
			for ( int i = 0; i < NUM_COLORS; i++ )
			{
				if ( item == buttonsColor[i] )
					settingColor = BUTTON_COLOR[i];
			}
		}
	}
	
	public static String turnText( int current, int last )
	{
//		String str = "";
//		if ( current < 10 )
//			str += " " + current + " ";
//		else
//			str += current;
//		str += " / ";
//		if ( last < 10 )
//			str += " " + last + " ";
//		else
//			str += last;
//		str += "";
//		return str;
		String str =  " " + current + " / " + last + " ";
		return str;
	}
	
	public void resetTurn(int index)
	{
		turns[index] = 0;
		labelsTurn[index].setText( turnText( turns[index], lastTurns[index] ) );
		repaint();
	}
	
	public void decreaseTurn(int index)
	{
		if ( turns[index] <= 0 )
			return;
		turns[index] -= 1;
		labelsTurn[index].setText( turnText( turns[index], lastTurns[index] ) );
		repaint();
	}
	
	public void increaseTurn(int index)
	{
		if ( turns[index] >= lastTurns[index] )
			return;
		turns[index] += 1;
		labelsTurn[index].setText( turnText( turns[index], lastTurns[index] ) );
		repaint();
	}
	
	public static String solutionsText( int current, int last )
	{
		if ( last < 0 )
			last = 0;
		String str =  " " + current + " / " + last + " ";
		return str;
	}
	
	public void resetSolution(int index)
	{
		solutions[index] = 0;
		buttonsSolution[index].setText( solutionsText( solutions[index], lastSolutions[index] ) );
		resetTurn(index);
		repaint();
	}
	
	public void cycleSolution(int index)
	{
		if ( lastSolutions[index] <= 0 )
			return;
		solutions[index] += 1;
		if ( solutions[index] > lastSolutions[index] )
			solutions[index] = 0;
		buttonsSolution[index].setText( solutionsText( solutions[index], lastSolutions[index] ) );
		resetTurn(index);
		repaint();
	}
	
	public void sortSolutions(int index)
	{
		if ( lastSolutions[index] <= 0 )
			return;
		int[] overhangs = this.overhangs[index];
		int[][][][] matrices = this.matrices[index];
		short[][][] locations = this.locations[index];
		int[][] holds = this.holds[index];
		int length = lastSolutions[index] + 1;
		
		for ( int outer = 1; outer < length; outer++ )
		{
			// sort array left of index
			for ( int inner = outer; inner > 0; inner-- )
			{
				if ( overhangs[inner] < overhangs[inner-1] )
				{
					int help = overhangs[inner];
					overhangs[inner] = overhangs[inner-1];
					overhangs[inner-1] = help;
					int[][][] help2 = matrices[inner];
					matrices[inner] = matrices[inner-1];
					matrices[inner-1] = help2;
					short[][] help3 = locations[inner];
					locations[inner] = locations[inner-1];
					locations[inner-1] = help3;
					int[] help4 = holds[inner];
					holds[inner] = holds[inner-1];
					holds[inner-1] = help4;
				}
				else
					break;
			}
		}
	}
	
	// y = row (0 is bottom), x = column (0 is left), s = block_size, c = color
	public void drawBlock(int y, int x, int c)
	{
		graphics.drawImage(skin, x0+blockSize*x, y0+blockSize*(-y), x0+blockSize*(x+1), y0+blockSize*(-y+1), skinSize*c, 0, skinSize*(c+1), skinSize, null);
	}
	
	public void  highlightBlock(int y, int x, Color c)
	{
		graphics.setColor(c);
		graphics.fillRect(x0+blockSize*x, y0+blockSize*(-y), blockSize, blockSize);
	}
	
	public int getColor(int piece)
	{
		if ( piece == FieldVar.piece_I )
			return COLOR_I;
		else if ( piece == FieldVar.piece_J )
			return COLOR_J;
		else if ( piece == FieldVar.piece_L )
			return COLOR_L;
		else if ( piece == FieldVar.piece_O )
			return COLOR_O;
		else if ( piece == FieldVar.piece_S )
			return COLOR_S;
		else if ( piece == FieldVar.piece_T )
			return COLOR_T;
		else if ( piece == FieldVar.piece_Z )
			return COLOR_Z;
		else if ( piece == FieldVar.piece_Unknown )
			return COLOR_FILLED;
		else // if ( piece == Field.piece_Invalid )
			return COLOR_INVALID;
	}
	
	public int getIndex(int piece)
	{
		if ( piece == FieldVar.piece_I )
			return FIELD_I;
		else if ( piece == FieldVar.piece_J )
			return FIELD_J;
		else if ( piece == FieldVar.piece_L )
			return FIELD_L;
		else if ( piece == FieldVar.piece_O )
			return FIELD_O;
		else if ( piece == FieldVar.piece_S )
			return FIELD_S;
		else if ( piece == FieldVar.piece_T )
			return FIELD_T;
		else if ( piece == FieldVar.piece_Z )
			return FIELD_Z;
		else
			return 0;
		
	}
	
	// called shortly after a repaint() call
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		graphics = g;
		for ( int i = 0; i < NUM_FIELDS; i++ )
		{
			drawFrame(i);
			drawField(i);
		}
		drawFrame( FIELD_ORIG );
		drawField( FIELD_ORIG );
	}
	
	public void drawFrame( int number )
	{
		int blockSize = BLOCK_SIZE[number];
		x0 = FIELD_X[number];
		y0 = FIELD_Y[number] + blockSize * ( FRAME_HEIGHT-1 );
		int north = FIELD_Y[number];
		int east = FIELD_X[number] + blockSize * MATRIX_WIDTH;
		int south = FIELD_Y[number] + blockSize * FRAME_HEIGHT;
		int west = FIELD_X[number];
		int size = blockSize/4; // blockSize = 16 -> frame is 4 pixels thick
		// draw corners
		graphics.drawImage( frameNW, west-size, north-size, west, north, 0, 0, frameNW.getWidth(), frameNW.getHeight(), null );
		graphics.drawImage( frameNW, east+size, north-size, east, north, 0, 0, frameNW.getWidth(), frameNW.getHeight(), null );
		graphics.drawImage( frameNW, east+size, south+size, east, south, 0, 0, frameNW.getWidth(), frameNW.getHeight(), null );
		graphics.drawImage( frameNW, west-size, south+size, west, south, 0, 0, frameNW.getWidth(), frameNW.getHeight(), null );
		// draw edges
		graphics.drawImage( frameN, west, north-size, east, north, 0, 0, frameN.getWidth(), frameN.getHeight(), null );
		graphics.drawImage( frameW, east+size, north, east, south, 0, 0, frameW.getWidth(), frameW.getHeight(), null );
		graphics.drawImage( frameN, west, south+size, east, south, 0, 0, frameN.getWidth(), frameN.getHeight(), null );
		graphics.drawImage( frameW, west-size, north, west, south, 0, 0, frameW.getWidth(), frameW.getHeight(), null );
		graphics.setColor( Color.black );
		graphics.fillRect( west, north, east-west, south-north );
	}
	
	public void drawField( int number )
	{
		// boolean[][] field = new boolean[FIELD_HEIGHT][FIELD_WIDTH];
		int[][] matrix;
		if ( number == FIELD_ORIG )
			matrix = this.matrix;
		else
			matrix = matrices[number][solutions[number]][turns[number]];
		int h; 
		if ( number == FIELD_ORIG )
			h = settingHeight;
		else
			h = MATRIX_HEIGHT;
		int w = MATRIX_WIDTH;
		boolean settingGray = ( number == FIELD_ORIG ) ? false : this.settingGray;
		
		blockSize = BLOCK_SIZE[number];
		x0 = FIELD_X[number];
		y0 = FIELD_Y[number] + blockSize * ( FRAME_HEIGHT-1 );
		
		int x; // x-coordinate of the current block
		int y; // y-coordinate of the current block
		int c; // color of the current block
		Color dark = new Color(0f, 0f, 0f, 0.3f);
		Color bright = new Color(1f, 1f, 1f, 0.35f);
		// draw content of playfield
		for ( y = 0; y < h; y++ )
		{
			boolean completed = true;
			completed = true;
			for ( x = 0; x < w; x++ )
				if ( matrix[y][x] == COLOR_EMPTY )
					completed = false;
			for ( x = 0; x < w; x++ )
			{
				boolean highlight = false;
				c = matrix[y][x];
				if ( c >= COLOR_ACTIVE )
				{
					c -= COLOR_ACTIVE;
					if ( settingGray == false )
						highlight = true;
				}
				else if ( settingGray == true && c != COLOR_EMPTY )
					c = COLOR_FILLED;
				drawBlock(y,x,c);
				if ( highlight && !completed )
					highlightBlock(y,x,bright);
				else if ( !highlight && completed )
					highlightBlock(y,x,dark);
			}
		}
		for ( y = h; y < MATRIX_HEIGHT; y++ )
		{
			for ( x = 0; x < w; x++ )
			{
				c = COLOR_INVALID;
				drawBlock(y,x,c);
			}
		}
		// next piece & hold piece
		if ( number != FIELD_ORIG && lastTurns[number] == 0 )
			return;
		int piece;
		for ( int i = 0; i < 3; i++ ) // i == 0 -> next Piece, i == 1 -> holdPiece
		{
			h = 2;
			w = 4;
			if ( i == 0 )
			{
				// x0 = FIELD_X[number] + blockSize * ( MATRIX_WIDTH-w );
				x0 = FIELD_X[number] + blockSize * ( MATRIX_WIDTH-w )/2;
				y0 = FIELD_Y[number] + blockSize * ( h-1 );
				if ( number == FIELD_ORIG )
				{
					if ( pieceSequence != null && pieceSequence.length > 1 )
						piece = pieceSequence[ 1 ];
					else
						piece = FieldVar.piece_Unknown;
				}
				else
					piece = pieces[ turns[number]+2 ];
			}
			else if ( i == 1 )
			{
				blockSize /= 2;
				x0 = FIELD_X[number];
				y0 = FIELD_Y[number] + blockSize * ( h-1 ) + blockSize;
				if ( number == FIELD_ORIG )
				{
					if ( pieceSequence != null && pieceSequence.length > 0 )
						piece = pieceSequence[ 0 ];
					else
						piece = FieldVar.piece_Unknown;
				}
				else
					piece = holds[number][solutions[number]][ turns[number] ];
			}
			else // if ( i == 2 )
			{
				x0 = FIELD_X[number] + blockSize * ( 2*MATRIX_WIDTH-w );
				y0 = FIELD_Y[number] + blockSize * ( h-1 ) + blockSize;
				if ( number == FIELD_ORIG )
				{
					if ( pieceSequence != null && pieceSequence.length > 2 )
						piece = pieceSequence[ 2 ];
					else
						piece = FieldVar.piece_Unknown;
				}
				else
					piece = pieces[ turns[number]+3 ];
			}
			// black background
			Color black = new Color(0f, 0f, 0f, 1f);
			for ( y = 0; y < h; y++ )
				for ( x = 0; x < w; x++ )
					highlightBlock(y,x,black);
			
			c = getColor(piece);
			if ( piece == FieldVar.piece_I )
				y0 -= blockSize/2;
			else if ( piece == FieldVar.piece_O )
				x0 += blockSize;
			else
				x0 += blockSize/2;
			
			if ( piece == FieldVar.piece_I )
			{ // draw horizontal I
				drawBlock( 0, 0, c );
				drawBlock( 0, 1, c );
				drawBlock( 0, 2, c );
				drawBlock( 0, 3, c );
			}
			else if ( piece == FieldVar.piece_O )
			{
				drawBlock( 0, 0, c );
				drawBlock( 0, 1, c );
				drawBlock( 1, 0, c );
				drawBlock( 1, 1, c );
			}
			else if ( piece == FieldVar.piece_T )
			{
				drawBlock( 0, 0, c );
				drawBlock( 0, 1, c );
				drawBlock( 0, 2, c );
				drawBlock( 1, 1, c );	
			}
			else if ( piece == FieldVar.piece_S )
			{
				drawBlock( 0, 0, c );
				drawBlock( 0, 1, c );
				drawBlock( 1, 1, c );
				drawBlock( 1, 2, c );
			}
			else if ( piece == FieldVar.piece_Z )
			{
				drawBlock( 1, 0, c );
				drawBlock( 1, 1, c );
				drawBlock( 0, 1, c );
				drawBlock( 0, 2, c );
			}
			else if ( piece == FieldVar.piece_L )
			{
				drawBlock( 0, 0, c );
				drawBlock( 0, 1, c );
				drawBlock( 0, 2, c );
				drawBlock( 1, 2, c );
			}
			else if ( piece == FieldVar.piece_J )
			{
				drawBlock( 1, 0, c );
				drawBlock( 0, 0, c );
				drawBlock( 0, 1, c );
				drawBlock( 0, 2, c );
			}
		}
	}
	
	public boolean[][] createInputMatrix( int height )
	{
		boolean[][] boolMatrix = new boolean[height][MATRIX_WIDTH];
		for ( int y = 0; y < height; y++ ) // rows
			for ( int x = 0; x < MATRIX_WIDTH; x++ )
				boolMatrix[y][x] = ( matrix[y][x] != COLOR_EMPTY );
		return boolMatrix;
	}
	
	public int numberOfEmptyCells( boolean[][] boolMatrix )
	{
		int empty = 0;
		for ( int y = 0; y < boolMatrix.length; y++ )
			for ( int x = 0; x < MATRIX_WIDTH; x++ )
				if ( boolMatrix[y][x] == false )
					empty += 1;
		return empty;
	}
	
	public short[] createInputSequence( int numPieces )
	{
		short[] pieces;
		if ( pieceSequence.length < numPieces )
			return null;
		pieces = new short[numPieces];
		for ( int i = 0; i < numPieces; i++ )
			pieces[i] = (short) pieceSequence[i];
		return pieces;
	}
	
	public int[] readPieceSequence()
	{
		String str = textSequence.getText().toUpperCase();
		if ( settingHold == false )
			str = "_" + str;
		else
			str = str + "_";
		int[] pieces = new int[ str.length() ];
		for ( int i = 0; i < str.length(); i++ )
		{
			char c = str.charAt(i);
			pieces[i] = FieldVar.charToShape(c);
			if ( pieces[i] == FieldVar.piece_Invalid )
				return null;
			if ( pieces[i] == FieldVar.piece_Unknown && i != 0 && !settingHold )
				return null;
			if ( pieces[i] == FieldVar.piece_Unknown && i != str.length()-1 && settingHold )
				return null;
		}
		return pieces;
	}
	
	public void updateMatrixWith( int[][] intMatrix, boolean[][] boolMatrix )
	{
		for ( int y = 0; y < boolMatrix.length; y++ )
			for ( int x = 0; x < MATRIX_WIDTH; x++ )
				intMatrix[y][x] = ( boolMatrix[y][x] == true ) ? COLOR_FILLED : COLOR_EMPTY;
		for ( int y = boolMatrix.length; y < MATRIX_HEIGHT; y++ )
			for ( int x = 0; x < MATRIX_WIDTH; x++ )
				intMatrix[y][x] = COLOR_EMPTY;
	}
	
	public void writeMessage( String str )
	{
		labelMessage.setText(str);
		repaint();
	}
	
	public int[][] croppedMatrix( int[][] matrix, int cropHeight )
	{
		int[][] croppedMatrix = new int[MATRIX_HEIGHT][MATRIX_WIDTH];
		for ( int row = 0; row < cropHeight; row++ )
			for ( int col = 0; col < MATRIX_WIDTH; col++ )
				croppedMatrix[row][col] = matrix[row][col];
		return croppedMatrix;
	}
	
	public void overwriteMatrixWith( int[][] matrix, int[][] father )
	{
		for ( int row = 0; row < MATRIX_HEIGHT; row++ )
			for ( int col = 0; col < MATRIX_WIDTH; col++ )
				matrix[row][col] = father[row][col];
	}
	
	public void colorMatrixWith( int[][] matrix, int[][] father )
	{
		int row2 = -1; // row in matrix
		for ( int row = 0; row < MATRIX_HEIGHT; row++ ) // row in father
		{
			row2 += 1;
			while ( true )
			{
				boolean completed = true;
				for ( int col = 0; col < MATRIX_WIDTH; col++ )
					if ( father[row][col] == COLOR_EMPTY )
						completed = false;
				if ( completed )
					row += 1;
				else
					break;
				if ( row >= MATRIX_HEIGHT )
					return;
			}
			for ( int col = 0; col < MATRIX_WIDTH; col++ )
			{
				if ( father[row][col] != COLOR_EMPTY )
				{
					if ( father[row][col] >= COLOR_ACTIVE )
						matrix[row2][col] = father[row][col] - COLOR_ACTIVE;
					else
						matrix[row2][col] = father[row][col];
				}
			}
		}
	}
	
	public void addNewSolution(int id)
	{
		lastSolutions[id] += 1;
		int length = lastSolutions[id] + 1;
		int[][][][] copyMatrices = new int[length][][][];
		short[][][] copyLocations = new short[length][][];
		int[][] copyHolds = new int[length][];
		int[] copyOverhangs = new int[length];
		int last = lastSolutions[id];
		for ( int sol = 0; sol < last; sol++ )
		{
			copyMatrices[sol] = matrices[id][sol];
			copyLocations[sol] = locations[id][sol];
			copyHolds[sol] = holds[id][sol];
			copyOverhangs[sol] = overhangs[id][sol];
		}
		int[][][] newMatrices = new int[NUM_TURNS][MATRIX_HEIGHT][MATRIX_WIDTH];
		short[][] newLocations = new short[NUM_TURNS][4];
		int[] newHolds = new int[NUM_TURNS];
		int newOverhangs = 0;
		copyMatrices[last] = newMatrices;
		copyLocations[last] = newLocations;
		copyHolds[last] = newHolds;
		copyOverhangs[last] = newOverhangs;
		matrices[id] = copyMatrices;
		locations[id] = copyLocations;
		holds[id] = copyHolds;
		overhangs[id] = copyOverhangs;
	}
	
	public void insertPieceAt( int[][] matrix, short[] location )
	{
		int piece = location[0];
		int dir = location[1];
		int row = location[2];
		int col = location[3];
		int color = getColor( piece );
		color += COLOR_ACTIVE;
	
		if ( piece == FieldVar.piece_T )
		{	
			if ( dir == 0 ) // north T piece
			{
				matrix[row+1][col+1] = color;
				matrix[row][col+2] = color;
				matrix[row][col+1] = color;
				matrix[row][col] = color;
			}
			else if ( dir == 1 ) // east T piece
			{
				matrix[row+1][col+1] = color;
				matrix[row][col] = color;
				matrix[row+1][col] = color;
				matrix[row+2][col] = color;
			}
			else if ( dir == 2 ) // south T piece
			{
				matrix[row+1][col+2] = color;
				matrix[row+1][col+1] = color;
				matrix[row+1][col] = color;
				matrix[row][col+1] = color;
			}
			else if ( dir == 3 ) // west T piece
			{
				matrix[row][col+1] = color;
				matrix[row+1][col+1] = color;
				matrix[row+2][col+1] = color;
				matrix[row+1][col] = color;
			}			
		}
		else if ( piece == FieldVar.piece_L )
		{		
			if ( dir == 0 ) // north L piece
			{
				matrix[row+1][col+2] = color;
				matrix[row][col+2] = color;
				matrix[row][col+1] = color;
				matrix[row][col] = color;
			}
			else if ( dir == 1 ) // east L piece
			{
				matrix[row][col+1] = color;
				matrix[row][col] = color;
				matrix[row+1][col] = color;
				matrix[row+2][col] = color;
			}
			else if ( dir == 2 ) // south L piece
			{
				matrix[row+1][col+2] = color;
				matrix[row+1][col+1] = color;
				matrix[row+1][col] = color;
				matrix[row][col] = color;
			}

			else if ( dir == 3 ) // west L piece
			{

				matrix[row][col+1] = color;
				matrix[row+1][col+1] = color;
				matrix[row+2][col+1] = color;
				matrix[row+2][col] = color;
			}			
		}
		else if ( piece == FieldVar.piece_J )
		{		
			if ( dir == 0 ) // north J piece
			{
				matrix[row+1][col] = color;
				matrix[row][col] = color;
				matrix[row][col+1] = color;
				matrix[row][col+2] = color;
			}
			else if ( dir == 1 ) // east J piece
			{
				matrix[row][col] = color;
				matrix[row+1][col] = color;
				matrix[row+2][col] = color;
				matrix[row+2][col+1] = color;
			}
			
			else if ( dir == 2 ) // south J piece
			{
				matrix[row+1][col] = color;
				matrix[row+1][col+1] = color;
				matrix[row+1][col+2] = color;
				matrix[row][col+2] = color;
			}
			else if ( dir == 3 ) // west J piece
			{
				matrix[row][col] = color;
				matrix[row][col+1] = color;
				matrix[row+1][col+1] = color;
				matrix[row+2][col+1] = color;
			}
		}
		else if ( piece == FieldVar.piece_S )
		{		
			if ( dir == 0 || dir == 2 ) // horizontal S piece
			{
				matrix[row+1][col+2] = color;
				matrix[row+1][col+1] = color;
				matrix[row][col+1] = color;
				matrix[row][col] = color;
			}
			else if ( dir == 1 || dir == 3 ) // vertical S piece
			{
				matrix[row][col+1] = color;
				matrix[row+1][col+1] = color;
				matrix[row+1][col] = color;
				matrix[row+2][col] = color;
			}
		}
		else if ( piece == FieldVar.piece_Z )
		{
			if ( dir == 0 || dir == 2 ) // horizontal Z piece
			{
				matrix[row+1][col] = color;
				matrix[row+1][col+1] = color;
				matrix[row][col+1] = color;
				matrix[row][col+2] = color;
			}
			else if ( dir == 1 || dir == 3 ) // vertical Z piece
			{
				matrix[row][col] = color;
				matrix[row+1][col] = color;
				matrix[row+1][col+1] = color;
				matrix[row+2][col+1] = color;
			}
		}
		else if ( piece == FieldVar.piece_I )
		{
			if ( dir == 0 || dir == 2 ) // horizontal I piece
			{
				matrix[row][col] = color;
				matrix[row][col+1] = color;
				matrix[row][col+2] = color;
				matrix[row][col+3] = color;
			}
			else if ( dir == 1 || dir == 3 ) // vertical I piece
			{
				matrix[row][col] = color;
				matrix[row+1][col] = color;
				matrix[row+2][col] = color;
				matrix[row+3][col] = color;
			}
		}
		else if ( piece == FieldVar.piece_O )
		{
			if ( dir <= 4 ) // every O piece
			{
				matrix[row+1][col] = color;
				matrix[row+1][col+1] = color;
				matrix[row][col+1] = color;
				matrix[row][col] = color;
			}
		}
	}
	
	public void executeCalculation()
	{
		pieceSequence = readPieceSequence();
		if ( pieceSequence == null )
		{
			writeMessage( "only letters I,T,O,L,J,S,Z are valid" );
			return;
		}
		boolean[][] inputMatrix = createInputMatrix( settingHeight );
		int emptyCells = numberOfEmptyCells( inputMatrix );
		if ( emptyCells % 4 != 0 )
		{
			writeMessage( "empty cells must be multiple of 4" );
			return;
		}
		int inputLast = emptyCells/4;
		short[] inputSequence = createInputSequence( inputLast+1 );
		if ( inputSequence == null )
		{
			writeMessage( "piece sequence too short" );
			return;
		}
		int[][] croppedMatrix = croppedMatrix( matrix, settingHeight );
		PerfectClearVar perfectClear = new PerfectClearVar( inputMatrix, inputSequence );
		PerfectClearVar.nodeLimit = settingNodes;
		if ( settingSoft == 0 )
			PerfectClearVar.check = PerfectClearVar.check_Surface;
		else if ( settingSoft == 1 )
		{
			PerfectClearVar.check = PerfectClearVar.check_Softdrop;
			FieldVar.useKicks = false;
			FieldVar.reverseSteps = 4;
		}
		else if ( settingSoft == 2 )
		{
			PerfectClearVar.check = PerfectClearVar.check_Softdrop;
			FieldVar.useKicks = true;
			FieldVar.reverseSteps = 3;
		}
		else if ( settingSoft == 3 )
			PerfectClearVar.check = PerfectClearVar.check_Deepdrop;
		PerfectClearVar.checkForSplits = true;
		PerfectClearVar.multipleSolutions = true;
		// run calculation
		writeMessage( "searching for perfect clears" );
		perfectClear.execute();
		// update data
		int numSolutions = 0;
		initVariables();
		for ( int i = 0; i <= inputLast; i++ )
			pieces[i] = inputSequence[i];
		Vector<FieldVar> queue = perfectClear.queue[inputLast];
		int curr = 0; int length = queue.size();
		while ( curr < length )
		{
			FieldVar field = queue.get( curr++ );
			if ( field.isEmpty() )
			{
				numSolutions += 1;
				int piece = field.piece;
				if ( inputSequence[inputLast] == FieldVar.piece_Unknown )
					piece = field.ancestor.piece;
				int id = getIndex( piece );
				if ( lastSolutions[id]+1 == NUM_SOLUTIONS )
					continue;
				if ( lastSolutions[id] >= 0 )
					addNewSolution( id );
				else
					lastSolutions[id] += 1;
				int sol = lastSolutions[id];
				lastTurns[id] = inputLast-1;
				overhangs[id][sol] = field.overhangs;
				for ( int turn = inputLast-1; turn >= 0; turn-- )
				{
					updateMatrixWith( matrices[id][sol][turn+1], field.getMatrix() );
					holds[id][sol][turn] = field.piece;
					locations[id][sol][turn] = field.reverseMove( inputSequence[turn+1] );
					field = field.ancestor;
				}
				overwriteMatrixWith( matrices[id][sol][0], croppedMatrix );
				// drop piece
				for ( int turn = 0; turn < inputLast; turn++ )
				{
					int[][] matrix = matrices[id][sol][turn];
					short[] location = locations[id][sol][turn];
					insertPieceAt( matrix, location );
				}
				// color matrices
				for ( int turn = 1; turn < inputLast; turn++ )
				{
					int[][] matrix = matrices[id][sol][turn];
					int[][] father = matrices[id][sol][turn-1];
					colorMatrixWith( matrix, father );
				}
			}
		}
		int numHold = 0;
		for ( int i = 0; i < NUM_FIELDS; i++ )
			if ( lastSolutions[i] >= 0 )
				numHold += 1;
		if ( numSolutions == 0 )
			writeMessage( "no solution found :(" );
		else
			writeMessage( numSolutions + " solutions found for " + numHold + " pieces in hold" );
		for ( int i = 0; i < NUM_FIELDS; i++ )
			sortSolutions(i);
		for ( int i = 0; i < NUM_FIELDS; i++ )
			resetSolution(i);
		// call garbage Collector
		perfectClear = null;
		queue = null;
		System.gc();
	}

	public void mousePressed( MouseEvent event )
	{
		int x = event.getX();
		int y = event.getY();
		int x0 = FIELD_X[FIELD_ORIG];
		int y0 = FIELD_X[FIELD_ORIG] + BLOCK_SIZE[FIELD_ORIG]*( FRAME_HEIGHT - MATRIX_HEIGHT );
		int w = BLOCK_SIZE[FIELD_ORIG]*MATRIX_WIDTH;
		int h = BLOCK_SIZE[FIELD_ORIG]*MATRIX_HEIGHT;
		if ( x < x0 || x >= x0 + w || y < y0 || y >= y0 + h )
			return;
		int col = (x-x0)/BLOCK_SIZE[FIELD_ORIG];
		int row = (y-y0)/BLOCK_SIZE[FIELD_ORIG];
		row = MATRIX_HEIGHT-1 - row;
		if ( row >= settingHeight )
			return;
		// System.out.println( "mouse pressed at row = " + row + " , col = " + col );
		if ( matrix[row][col] == settingColor )
			matrix[row][col] = COLOR_EMPTY;
		else
			matrix[row][col] = settingColor;
		repaint();
	}
	
	public void mouseClicked(MouseEvent arg0){}
	public void mouseEntered(MouseEvent arg0){}
	public void mouseExited(MouseEvent arg0){}
	public void mouseReleased(MouseEvent arg0){}
	
	public static void main( String[] args )
	{
		new PcVisualizer();
	}
}