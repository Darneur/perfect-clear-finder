package oki.pc;
import java.util.Vector;

import oki.avl.AvlTree;

public class PerfectClearVar
{
	public static final int check_Surface = 0,
							check_Softdrop = 1,
							check_Deepdrop = 2;
	
	static int check = check_Softdrop;
	static int nodeLimit = 100000000;
	static boolean checkForSplits = true;
	static boolean multipleSolutions = false;
	
	short[] pieces; // given piece sequence (first piece is put on hold)
	Vector<FieldVar>[] queue; // queue[depth], list containing the data of all created fields
	AvlTree[] tree; // tree[depth], sorts all created fields
	int[] mergings;
	int[] nodes;
	
	@SuppressWarnings("unchecked")
	public PerfectClearVar( boolean[][] matrix, short[] pieces )
	{
		// matrix[row][col] whereas row = 0 means bottom, and col = 0 means left side
		this.pieces = pieces;
		FieldVar startField = new FieldVar( matrix );
		startField.piece = (byte) pieces[0];
		startField.ancestor = null;
		// startField.paths = 1;
		startField.overhangs = startField.overhangCells(); // kinda useless
		
		queue = new Vector[pieces.length];
		tree = new AvlTree[pieces.length];
		mergings = new int[pieces.length-1];
		nodes = new int[pieces.length-1];
			
		queue[0] = new Vector<FieldVar>();
		tree[0] = new AvlTree();
		queue[0].add( 0, startField);
		tree[0].insert(startField);
		
		FieldVar.calculateAdjustedKicks();
	}
	
	public static boolean acceptMove( FieldVar field, short[] location )
	{
		if ( check == check_Softdrop && !field.locationIsReachable(location) )
			return false;
		else if ( check == check_Surface && !field.locationOnSurface(location) )
			return false;
		else if ( checkForSplits && field.hasOddSplit() )
			return false;
		return true;
	}
	
	public void process(int depth)
	{
		queue[depth+1] = new Vector<FieldVar>();
		tree[depth+1] = new AvlTree();
		Vector<FieldVar> thisQueue = queue[depth];
		Vector<FieldVar> nextQueue = queue[depth+1];
		AvlTree nextTree = tree[depth+1];
		short activePiece = pieces[depth+1];
		int duplicates = 0;
		int thisCurr = 0;
		int thisLength = thisQueue.size();
		int nextLength = 0;
		
		while( thisCurr < thisLength && nextLength < nodeLimit )
		{
			FieldVar thisField = thisQueue.get( thisCurr++ );
			short[] location = thisField.resetLocation(activePiece);
			while ( thisField.getNextLocation(location) )
			{
				if ( !acceptMove( thisField, location ) )
					continue;
				FieldVar nextField = thisField.createField(location,activePiece);			
				// System.out.println( nextField.toString() );
				FieldVar treeField = null;
				if ( depth < pieces.length-2 || !multipleSolutions )
					treeField = (FieldVar) nextTree.find( nextField );
				if ( treeField != null )
				{
					duplicates += 1;
					// treeField.paths += nextField.paths;
					if ( nextField.overhangs < treeField.overhangs )
					{
						treeField.ancestor = nextField.ancestor;
						treeField.overhangs = nextField.overhangs;
					}
				}
				else
				{
					nextQueue.add( nextLength++, nextField );
					nextTree.insert( nextField );
				}
			}
		}
		mergings[depth] = duplicates;
		nodes[depth] = nextLength;
	}
	
	public void execute()
	{
		for ( int i = 0; i < pieces.length-1; i++ ) // pieces.length-1
		{
			long start = System.currentTimeMillis();
			process(i);
			long end = System.currentTimeMillis();
			queue[i] = null; // freeing memory-usage
			System.out.println("depth " + i + " finished in " + (end - start) + " ms , valid fields = " + nodes[i] + " , mergings = " + mergings[i] + " , memory = " + getMemory()/1024 );
		}
	}
	
    private static long getMemory()
    {
        Runtime runtime = Runtime.getRuntime();
        return runtime.totalMemory() - runtime.freeMemory();
    }
    
	public void statistics()
	{
		Vector<FieldVar> finalQueue = queue[pieces.length-1];
		int curr = 0; int length = finalQueue.size();
		int numSolutions = 0; // int sumPaths = 0;
		while ( curr < length )
		{
			FieldVar field = finalQueue.get( curr++ );
			if ( field.isEmpty() )
			{
				numSolutions += 1;
				// sumPaths += field.paths;
				char c = FieldVar.shapeToChar( field.piece );
				// System.out.println( "\n" + "Found a solution with " + field.paths + " different paths (" + c + " on hold)");
				System.out.println( "\n" + "Found a solution with " + field.overhangs + " overhang cells in total (" + c + " on hold)");
				System.out.println( field.ancestorString() );
			}
		}
		System.out.println();
		if ( numSolutions > 0 )
			// System.out.println( "found solutions with " + numSolutions + " different pieces on hold and " + sumPaths + " paths in total" );
			System.out.println( "found solutions with " + numSolutions + " different pieces on hold" );
		else
			System.out.println("NO SOLUTION found :(" );
	}
		
	public static void main1(String[] args)
	{
		if ( args.length == 0 || args[0].length() != 11 )
		{
			System.out.println( "first parameter must be a word consisting of 11 letters e.g. JIZLOTSLITO");
			return;
		}
		String str = args[0].toUpperCase();
		short[] pieces = new short[ str.length() ];
		for ( int i = 0; i < str.length(); i++ )
		{
			char c = str.charAt(i);
			pieces[i] = (short) FieldVar.charToShape(c);
			if ( pieces[i] == FieldVar.piece_Invalid )
			{
				System.out.println( "only the letters I, T, O, L, J, S, Z, _ are valid for the first parameter");
				return;
			}
			else if ( i > 0 && i < 10 && pieces[i] == FieldVar.piece_Unknown ) 
			{
				System.out.println( "the letter _ is only valid at the start and at the end of the word");
				return;
			}
			else if ( i == 10 && pieces[0] == FieldVar.piece_Unknown && pieces[10] == FieldVar.piece_Unknown )
			{
				System.out.println( "the word can't contain _ two times, 10 pieces needed at least");
				return;
			}
		}
		if ( args.length >= 2 )
		{
			if ( args[1].equals("0") )
				check = check_Surface;
			else if ( args[1].equals("1") )
				check = check_Softdrop;
			else if ( args[1].equals("2") )
				check = check_Deepdrop;
		}
		String str2 = "";
		if ( check == check_Surface )
			str2 = " (using only harddrop)";
		else if ( check == check_Softdrop )
			str2 = " (using softdrop and kicks)";
		else if ( check == check_Deepdrop )
			str2 = " (using deepdrop)";
		if ( args.length >= 3 )
		{
			if ( args[2].equals("0") )
				nodeLimit = 1000000;
			else // if ( args[2].equals("1") )
				nodeLimit = 100000000;
		}
		String str3 = "";
		if ( nodeLimit <= 10000000 )
			str3 = " (field limit = " + nodeLimit + ")";
		else
			str3 = " (no field limit)";
		if ( args.length >= 4 )
		{
			if ( args[3].equals("0") )
				multipleSolutions = true;
			else
				multipleSolutions = false;
		}
		String str4 = "";
		if ( multipleSolutions )
			str4 = " (multiple solutions)";
		else
			str4 = " (one solution per hold)";
		System.out.println( "try to find perfect clears for the sequence " + str + str2 + str3 + str4 );
		boolean[][] matrix = new boolean[4][10];
		PerfectClearVar instance = new PerfectClearVar( matrix, pieces );
		long start = System.currentTimeMillis();
		instance.execute();
		long end = System.currentTimeMillis();
		instance.statistics();
		System.out.println("FINISHED the whole calculation in " + (end - start) + " ms" );
		
	}
	
	public static boolean[][] convertMirroredMatrix( int[][] intMatrix )
	{
		boolean[][] boolMatrix = new boolean[intMatrix.length][];
		for ( int y = 0; y < intMatrix.length; y++ )
		{
			int z = intMatrix.length - 1 - y;
			boolMatrix[z] = new boolean[intMatrix[y].length];
			for ( int x = 0; x < intMatrix[y].length; x++ )
				boolMatrix[z][x] = ( intMatrix[y][x] != 0 );
		}
		return boolMatrix;
	}
	
	@SuppressWarnings("unused")
	public static void test1()
	{
		int _ = 0;
		int X = 1;
		int[][] intMatrix = 
		{
			{_,_,_,_,_,_,_,_,_,_},
			{_,_,_,_,_,_,_,_,_,_},
			{X,_,_,X,X,_,_,X,X,X},
			{X,_,_,X,_,_,X,X,X,X},
		};
		boolean[][] matrix = convertMirroredMatrix( intMatrix );
		short I = FieldVar.piece_I;
		short T = FieldVar.piece_T;
		short O = FieldVar.piece_O;
		short L = FieldVar.piece_L;
		short J = FieldVar.piece_J;
		short S = FieldVar.piece_S;
		short Z = FieldVar.piece_Z;
		short[] pieces = new short[]{ O, I, S };
		FieldVar.goal = 2;
		PerfectClearVar instance = new PerfectClearVar( matrix, pieces );
		instance.execute();
		instance.statistics();
	}
	
	@SuppressWarnings("unused")
	public static void test2()
	{
		int _ = 0;
		int X = 1;
		int[][] intMatrix = 
		{
			{_,_,_,_,_,_,_,_,_,_},
			{_,_,_,_,_,_,_,_,_,_},
			{X,X,X,_,_,X,X,X,X,X},
			{X,X,_,_,X,X,X,X,X,X},
		};
		boolean[][] matrix = convertMirroredMatrix( intMatrix );
		short I = FieldVar.piece_I;
		short T = FieldVar.piece_T;
		short O = FieldVar.piece_O;
		short L = FieldVar.piece_L;
		short J = FieldVar.piece_J;
		short S = FieldVar.piece_S;
		short Z = FieldVar.piece_Z;
		FieldVar.calculateAdjustedKicks();
		FieldVar.reverseSteps = 4;
		FieldVar field = new FieldVar( matrix );
		System.out.println( field );
		short[] location = { S, 0, 0, 2 };
		System.out.println( "collision = " + field.collision(location) );
		boolean reachable = field.locationIsReachable(location);
		System.out.println( "reachable = " + reachable );
	}
	
	@SuppressWarnings("unused")
	public static void test3()
	{
		int _ = 0;
		int X = 1;
//		int[][] intMatrix = 
//		{
//			{_,_,_,_,_,_,_,_,_,_},
//			{_,_,_,_,_,_,_,_,_,_},
//			{X,X,_,_,_,_,X,X,X,X},
//			{X,X,X,_,_,_,_,X,X,X},
//		};
		int[][] intMatrix = 
		{
			{_,_,_,_,_,_,_,_,_,_},
			{_,_,_,_,_,_,_,_,_,_},
			{X,X,X,X,_,_,_,_,X,X},
			{X,X,X,_,_,_,_,X,X,X},
		};
		boolean[][] matrix = convertMirroredMatrix( intMatrix );
		short I = FieldVar.piece_I;
		short T = FieldVar.piece_T;
		short O = FieldVar.piece_O;
		short L = FieldVar.piece_L;
		short J = FieldVar.piece_J;
		short S = FieldVar.piece_S;
		short Z = FieldVar.piece_Z;
		FieldVar.calculateAdjustedKicks();
		FieldVar.reverseSteps = 4;
		FieldVar field = new FieldVar( matrix );
		System.out.println( field );
		short[] location = { I, 0, 0, 3 };
		System.out.println( "collision = " + field.collision(location) );
		boolean reachable = field.locationIsReachable(location);
		System.out.println( "reachable = " + reachable );
	}
	
	@SuppressWarnings("unused")
	public static void test4()
	{
		int _ = 0;
		int X = 1;
		int[][] intMatrix = 
		{
			{_,_,X,X,X,X,X,X,X,X},
			{_,_,_,X,X,X,X,X,X,X},
			{X,X,_,X,X,X,X,X,X,X},
			{X,_,_,X,X,X,X,X,X,X},
			{X,_,_,_,X,X,X,X,X,X},
			{X,X,_,X,X,X,X,X,X,X},
			{X,X,_,X,X,X,X,X,X,X},
		};
		boolean[][] matrix = convertMirroredMatrix( intMatrix );
		short I = FieldVar.piece_I;
		short T = FieldVar.piece_T;
		short O = FieldVar.piece_O;
		short L = FieldVar.piece_L;
		short J = FieldVar.piece_J;
		short S = FieldVar.piece_S;
		short Z = FieldVar.piece_Z;
		FieldVar.calculateAdjustedKicks();
		FieldVar.reverseSteps = 4;
		FieldVar field = new FieldVar( matrix );
		System.out.println( field );
		short[] location = { T, 2, 1, 1 };
		System.out.println( "collision = " + field.collision(location) );
		boolean reachable = field.locationIsReachable(location);
		System.out.println( "reachable = " + reachable );
	}
	
	@SuppressWarnings("unused")
	public static void test5()
	{
		int _ = 0;
		int X = 1;
		int[][] intMatrix = 
		{
			{_,_,_,_,_,_,_,_,_,_},
			{X,X,_,_,_,_,_,_,_,_},
			{X,X,X,_,_,_,X,_,_,_},
			{X,X,X,_,_,X,X,X,X,X},
			{X,X,X,_,_,X,X,X,X,X},
			{X,X,X,_,_,X,X,X,X,X},
			{X,X,X,_,_,_,X,X,X,X},
			{X,X,X,X,_,X,X,_,_,X},
		};
		boolean[][] matrix = convertMirroredMatrix( intMatrix );
		short I = FieldArr.piece_I;
		short T = FieldArr.piece_T;
		short O = FieldArr.piece_O;
		short L = FieldArr.piece_L;
		short J = FieldArr.piece_J;
		short S = FieldArr.piece_S;
		short Z = FieldArr.piece_Z;
		short[] pieces = new short[]{ O, T, L, I, J, Z, I, T, O, T };
		PerfectClearVar instance = new PerfectClearVar( matrix, pieces );
		instance.execute();
		instance.statistics();
	}
	
	@SuppressWarnings("unused")
	public static void test6()
	{
		int _ = 0;
		int X = 1;
		int[][] intMatrix = 
		{
			{X,X,X,X,X,_,_,_,_,_},
			{X,X,X,X,X,X,_,_,_,_},
			{X,X,X,X,X,X,X,_,_,_},
			{X,X,X,X,X,X,_,_,_,_},
			{_,_,_,_,_,X,X,X,X,X},
			{_,_,_,_,X,X,X,X,X,X},
			{_,_,_,X,X,X,X,X,X,X},
			{_,_,_,_,X,X,X,X,X,X},
		};
		boolean[][] matrix = convertMirroredMatrix( intMatrix );
		short I = FieldArr.piece_I;
		short T = FieldArr.piece_T;
		short O = FieldArr.piece_O;
		short L = FieldArr.piece_L;
		short J = FieldArr.piece_J;
		short S = FieldArr.piece_S;
		short Z = FieldArr.piece_Z;
		short[] pieces = new short[]{ I, Z, T, J, I, S, Z, T, O };
		PerfectClearVar instance = new PerfectClearVar( matrix, pieces );
		instance.execute();
		instance.statistics();
	}
	
	public static void test7()
	{
		int _ = 0;
		int X = 1;
		int[][] intMatrix = 
		{
			{X,_,_,_,_,_,_,_,_,_},
			{_,_,X,_,_,_,_,_,_,_},
			{X,_,_,_,_,_,_,_,_,_},
			{X,_,_,_,X,X,_,_,_,_},
			{_,_,_,_,X,X,X,X,X,X},
			{_,_,X,_,X,X,X,_,X,X},
			{X,_,X,_,X,X,X,_,_,X},
			{_,_,_,_,X,X,X,X,_,_},
		};
		boolean[][] matrix = convertMirroredMatrix( intMatrix );
		FieldVar field = new FieldVar( matrix );
		System.out.println( field );
		System.out.println( field.overhangCells() );
	}
	
	public static void main(String[] args)
	{
		main1(args);
		// test7();
	}
}

